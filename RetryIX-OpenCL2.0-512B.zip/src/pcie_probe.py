# pcie_probe.py
# Plug-in PCIe throughput probe: supports both SVM and Pinned (pure DMA) measurements
# Dependencies: pyopencl, enhanced_ctypes_svm (your module)
import pyopencl
import time
import ctypes
import argparse
import numpy as np
import pyopencl as cl
import enhanced_ctypes_svm as svm_mod

# ---- Configurable Parameters ----
SVM_BYTES     = 128 * 1024 * 1024   # SVM measurement size (recommended at least 128MB)
PINNED_BYTES  = 512 * 1024 * 1024   # Pinned measurement size (recommended 512MB+ for stability)
TRIALS        = 5                   # Multiple measurements for median
KEEPALIVE_BYTES = 0                 # 0=off, >0 will send a small packet to keep link L0 (recommended 128~256KB)

# ---- Utilities ----
def _median(xs):
    xs = sorted(xs); n = len(xs)
    return 0.0 if n == 0 else (xs[n//2] if n % 2 else 0.5*(xs[n//2-1] + xs[n//2]))

def _classify_link(gbps: float) -> str:
    if gbps >= 28: return "PCIe 4.0 x16"
    if gbps >= 14: return "PCIe 4.0 x8 / PCIe 3.0 x16"
    if gbps >= 7:  return "PCIe 3.0 x8"
    if gbps >= 3.5:return "PCIe 3.0 x4 / PCIe 4.0 x2"
    return "Degraded (x1~x2 / PCH/bridge)"

def _suggest_stripe_and_code(eff_gbps: float):
    # Provide stripe/error correction strategy recommendations based on effective throughput (can be fine-tuned for specific hardware)
    if eff_gbps < 7:    return 128*1024, "LRC"
    if eff_gbps < 14:   return 256*1024, "LRC"
    if eff_gbps < 28:   return 512*1024, "LRC_RS_MIX"
    return 1*1024*1024, "RS"

def _get_pci_bus_info(dev):
    # Try to read cl_khr_pci_bus_info (returns None if driver/pyopencl doesn't support)
    try:
        exts = dev.extensions.split()
        if "cl_khr_pci_bus_info" in exts:
            pci_info_id = getattr(cl.device_info, "PCI_BUS_INFO_KHR", None)
            if pci_info_id is not None:
                d, b, dv, f = dev.get_info(pci_info_id)
                return f"{d:04x}:{b:02x}:{dv:02x}.{f}"
    except Exception:
        pass
    return None

def _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl):
    # Send a small DMA packet to keep link in L0, reducing OS power-saving downclocking
    mf = cl.mem_flags
    hb = cl.Buffer(ctx, mf.ALLOC_HOST_PTR | mf.READ_WRITE, size=keepalive_bytes)
    arr, _ = cl.enqueue_map_buffer(
        queue, hb, cl.map_flags.WRITE, 0, (keepalive_bytes,), np.uint8, is_blocking=True
    )
    cl.enqueue_copy(queue, dev_buf, hb)
    if hasattr(hb, "enqueue_unmap"):
        event = hb.enqueue_unmap(queue, arr)
        event.wait()
    else:
        queue.finish()

# ---- Probe: SVM Path (represents actual runtime data path) ----
def measure_svm_pcie_gbps(bytes_len=SVM_BYTES, trials=TRIALS, keepalive_bytes=KEEPALIVE_BYTES):
    svm_mgr = svm_mod.create_svm_manager('gpu', prefer_tested=True)
    if not svm_mgr:
        raise RuntimeError("Unable to create SVM manager, please check driver/hardware")
    ctx, queue, dev = svm_mgr.context, svm_mgr.queue, svm_mgr.device
    mf = cl.mem_flags

    dev_buf = cl.Buffer(ctx, mf.READ_WRITE, size=bytes_len)
    if keepalive_bytes and keepalive_bytes > 0:
        _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl)

    # Allocate SVM and create numpy view
    svm_ptr = svm_mgr.allocate(bytes_len, alignment=64, name='svm_probe')
    host_view = np.ctypeslib.as_array((ctypes.c_ubyte * bytes_len).from_address(svm_ptr))
    host_view[:] = 1

    # warm-up (avoid first packet jitter)
    cl.enqueue_copy(queue, dev_buf, host_view, is_blocking=True)
    cl.enqueue_copy(queue, host_view, dev_buf, is_blocking=True)

    h2d, d2h = [], []
    for _ in range(trials):
        t0 = time.perf_counter()
        cl.enqueue_copy(queue, dev_buf, host_view, is_blocking=True)
        h2d.append(bytes_len / (time.perf_counter() - t0) / 1e9)

        t0 = time.perf_counter()
        cl.enqueue_copy(queue, host_view, dev_buf, is_blocking=True)
        d2h.append(bytes_len / (time.perf_counter() - t0) / 1e9)

    svm_mgr.free(svm_ptr, 'svm_probe')

    H2D, D2H = _median(h2d), _median(d2h)
    eff = min(H2D, D2H)
    cls = _classify_link(eff)
    return {
        "mode": "svm",
        "device": dev.name,
        "platform": dev.platform.name,
        "pci_bus": _get_pci_bus_info(dev),
        "H2D_GBps": H2D,
        "D2H_GBps": D2H,
        "effective_GBps": eff,
        "class": cls,
        "suggest": _suggest_stripe_and_code(eff),
    }

# ---- Probe: Pinned Host (pure DMA upper limit) ----
def measure_pinned_pcie_gbps(bytes_len=PINNED_BYTES, trials=TRIALS, keepalive_bytes=KEEPALIVE_BYTES, cl=cl):
    # Share the same context/queue/device with SVM path to maintain consistency
    svm_mgr = svm_mod.create_svm_manager('gpu', prefer_tested=True)
    if not svm_mgr:
        raise RuntimeError("Unable to create SVM manager, please check driver/hardware")
    ctx, queue, dev = svm_mgr.context, svm_mgr.queue, svm_mgr.device
    mf = cl.mem_flags

    dev_buf = cl.Buffer(ctx, mf.READ_WRITE, size=bytes_len)
    if keepalive_bytes and keepalive_bytes > 0:
        _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl)

    # Pinned host buffer: ALLOC_HOST_PTR + map to ndarray (shape/dtype interface)
    host_buf = cl.Buffer(ctx, mf.ALLOC_HOST_PTR | mf.READ_WRITE, size=bytes_len)
    host_arr, _ = cl.enqueue_map_buffer(
        queue, host_buf, cl.map_flags.WRITE, 0, (bytes_len,), np.uint8, is_blocking=True
    )
    host_arr[:] = 1

    # warm-up
    cl.enqueue_copy(queue, dev_buf, host_buf)
    cl.enqueue_copy(queue, host_buf, dev_buf)

    # Use profiling-enabled queue to get event timing, accurately reflecting DMA
    q_prof = cl.CommandQueue(ctx, properties=cl.command_queue_properties.PROFILING_ENABLE)

    def _gbps(evt):
        evt.wait()
        t = (evt.profile.end - evt.profile.start) * 1e-9  # ns → s
        return bytes_len / t / 1e9

    h2d, d2h = [], []
    for _ in range(trials):
        e = cl.enqueue_copy(q_prof, dev_buf, host_buf); h2d.append(_gbps(e))
        e = cl.enqueue_copy(q_prof, host_buf, dev_buf); d2h.append(_gbps(e))

    if hasattr(host_buf, "enqueue_unmap"):
        event = host_buf.enqueue_unmap(queue, host_arr)
        event.wait()
    else:
        queue.finish()

    H2D, D2H = _median(h2d), _median(d2h)
    eff = min(H2D, D2H)
    cls = _classify_link(eff)
    return {
        "mode": "pinned",
        "device": dev.name,
        "platform": dev.platform.name,
        "pci_bus": _get_pci_bus_info(dev),
        "H2D_GBps": H2D,
        "D2H_GBps": D2H,
        "effective_GBps": eff,
        "class": cls,
        "suggest": _suggest_stripe_and_code(eff),
    }

# ---- CLI ----
def main():
    ap = argparse.ArgumentParser(description="RetryIX PCIe Probe (SVM & Pinned)")
    ap.add_argument("--mode", choices=["svm", "pinned", "both"], default="both")
    ap.add_argument("--svm-bytes", type=int, default=SVM_BYTES)
    ap.add_argument("--pinned-bytes", type=int, default=PINNED_BYTES)
    ap.add_argument("--trials", type=int, default=TRIALS)
    ap.add_argument("--keepalive-bytes", type=int, default=KEEPALIVE_BYTES)
    args = ap.parse_args()

    if args.mode in ("svm", "both"):
        r = measure_svm_pcie_gbps(args.svm_bytes, args.trials, args.keepalive_bytes)
        s_kb, code = r["suggest"]
        print(f"[SVM]    H2D {r['H2D_GBps']:.2f} GB/s, D2H {r['D2H_GBps']:.2f} GB/s → {r['class']} "
              f"(Device={r['device']}, Platform={r['platform']}, Bus={r['pci_bus']})")
        print(f"         ↳ Recommendation: stripe={s_kb//1024}KB, code={code}")

    if args.mode in ("pinned", "both"):
        r = measure_pinned_pcie_gbps(args.pinned_bytes, args.trials, args.keepalive_bytes, cl)
        s_kb, code = r["suggest"]
        print(f"[Pinned] H2D {r['H2D_GBps']:.2f} GB/s, D2H {r['D2H_GBps']:.2f} GB/s → {r['class']} "
              f"(Device={r['device']}, Platform={r['platform']}, Bus={r['pci_bus']})")
        print(f"         ↳ Recommendation: stripe={s_kb//1024}KB, code={code}")

if __name__ == "__main__":
    main()