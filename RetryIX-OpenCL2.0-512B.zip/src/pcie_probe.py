# pcie_probe.py
# 外掛式 PCIe 吞吐探針：同時支援 SVM 與 Pinned（純 DMA）量測
# 依賴：pyopencl、enhanced_ctypes_svm（你的模組）
import pyopencl
import time
import ctypes
import argparse
import numpy as np
import pyopencl as cl
import enhanced_ctypes_svm as svm_mod

# ---- 可調參數 ----
SVM_BYTES     = 128 * 1024 * 1024   # SVM 量測大小（建議至少 128MB）
PINNED_BYTES  = 512 * 1024 * 1024   # Pinned 量測大小（建議 512MB 以上更穩）
TRIALS        = 5                   # 多次量測取中位數
KEEPALIVE_BYTES = 0                 # 0=關，>0 時會先丟一個小包保持鏈路 L0（建議 128~256KB）

# ---- 工具 ----
def _median(xs):
    xs = sorted(xs); n = len(xs)
    return 0.0 if n == 0 else (xs[n//2] if n % 2 else 0.5*(xs[n//2-1] + xs[n//2]))

def _classify_link(gbps: float) -> str:
    if gbps >= 28: return "PCIe 4.0 x16"
    if gbps >= 14: return "PCIe 4.0 x8 / PCIe 3.0 x16"
    if gbps >= 7:  return "PCIe 3.0 x8"
    if gbps >= 3.5:return "PCIe 3.0 x4 / PCIe 4.0 x2"
    return "Degraded (x1~x2 / PCH/bridge)"

def _suggest_stripe_and_code(eff_gbps: float):
    # 依有效吞吐給出條帶/容錯策略建議（可視實機再微調）
    if eff_gbps < 7:    return 128*1024, "LRC"
    if eff_gbps < 14:   return 256*1024, "LRC"
    if eff_gbps < 28:   return 512*1024, "LRC_RS_MIX"
    return 1*1024*1024, "RS"

def _get_pci_bus_info(dev):
    # 嘗試讀 cl_khr_pci_bus_info（若驅動/pyopencl 不支援則回 None）
    try:
        exts = dev.extensions.split()
        if "cl_khr_pci_bus_info" in exts:
            pci_info_id = getattr(cl.device_info, "PCI_BUS_INFO_KHR", None)
            if pci_info_id is not None:
                d, b, dv, f = dev.get_info(pci_info_id)
                return f"{d:04x}:{b:02x}:{dv:02x}.{f}"
    except Exception:
        pass
    return None

def _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl):
    # 丟一個小包 DMA 讓鏈路留在 L0，減少 OS 省電降檔
    mf = cl.mem_flags
    hb = cl.Buffer(ctx, mf.ALLOC_HOST_PTR | mf.READ_WRITE, size=keepalive_bytes)
    arr, _ = cl.enqueue_map_buffer(
        queue, hb, cl.map_flags.WRITE, 0, (keepalive_bytes,), np.uint8, is_blocking=True
    )
    cl.enqueue_copy(queue, dev_buf, hb)
    if hasattr(hb, "enqueue_unmap"):
        event = hb.enqueue_unmap(queue, arr)
        event.wait()
    else:
        queue.finish()

# ---- 探針：SVM 路徑（代表實際運行的資料路徑）----
def measure_svm_pcie_gbps(bytes_len=SVM_BYTES, trials=TRIALS, keepalive_bytes=KEEPALIVE_BYTES):
    svm_mgr = svm_mod.create_svm_manager('gpu', prefer_tested=True)
    if not svm_mgr:
        raise RuntimeError("無法建立 SVM 管理器，請檢查驅動/硬體")
    ctx, queue, dev = svm_mgr.context, svm_mgr.queue, svm_mgr.device
    mf = cl.mem_flags

    dev_buf = cl.Buffer(ctx, mf.READ_WRITE, size=bytes_len)
    if keepalive_bytes and keepalive_bytes > 0:
        _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl)

    # 分配 SVM 並建立 numpy 視圖
    svm_ptr = svm_mgr.allocate(bytes_len, alignment=64, name='svm_probe')
    host_view = np.ctypeslib.as_array((ctypes.c_ubyte * bytes_len).from_address(svm_ptr))
    host_view[:] = 1

    # warm-up（避免首包抖動）
    cl.enqueue_copy(queue, dev_buf, host_view, is_blocking=True)
    cl.enqueue_copy(queue, host_view, dev_buf, is_blocking=True)

    h2d, d2h = [], []
    for _ in range(trials):
        t0 = time.perf_counter()
        cl.enqueue_copy(queue, dev_buf, host_view, is_blocking=True)
        h2d.append(bytes_len / (time.perf_counter() - t0) / 1e9)

        t0 = time.perf_counter()
        cl.enqueue_copy(queue, host_view, dev_buf, is_blocking=True)
        d2h.append(bytes_len / (time.perf_counter() - t0) / 1e9)

    svm_mgr.free(svm_ptr, 'svm_probe')

    H2D, D2H = _median(h2d), _median(d2h)
    eff = min(H2D, D2H)
    cls = _classify_link(eff)
    return {
        "mode": "svm",
        "device": dev.name,
        "platform": dev.platform.name,
        "pci_bus": _get_pci_bus_info(dev),
        "H2D_GBps": H2D,
        "D2H_GBps": D2H,
        "effective_GBps": eff,
        "class": cls,
        "suggest": _suggest_stripe_and_code(eff),
    }

# ---- 探針：Pinned Host（純 DMA 上限）----
def measure_pinned_pcie_gbps(bytes_len=PINNED_BYTES, trials=TRIALS, keepalive_bytes=KEEPALIVE_BYTES, cl=cl):
    # 與 SVM 路徑共用同一個 context/queue/device，維持一致性
    svm_mgr = svm_mod.create_svm_manager('gpu', prefer_tested=True)
    if not svm_mgr:
        raise RuntimeError("無法建立 SVM 管理器，請檢查驅動/硬體")
    ctx, queue, dev = svm_mgr.context, svm_mgr.queue, svm_mgr.device
    mf = cl.mem_flags

    dev_buf = cl.Buffer(ctx, mf.READ_WRITE, size=bytes_len)
    if keepalive_bytes and keepalive_bytes > 0:
        _enqueue_keepalive(queue, ctx, dev_buf, keepalive_bytes, cl)

    # Pinned host buffer：ALLOC_HOST_PTR + map 成 ndarray（shape/dtype 介面）
    host_buf = cl.Buffer(ctx, mf.ALLOC_HOST_PTR | mf.READ_WRITE, size=bytes_len)
    host_arr, _ = cl.enqueue_map_buffer(
        queue, host_buf, cl.map_flags.WRITE, 0, (bytes_len,), np.uint8, is_blocking=True
    )
    host_arr[:] = 1

    # warm-up
    cl.enqueue_copy(queue, dev_buf, host_buf)
    cl.enqueue_copy(queue, host_buf, dev_buf)

    # 用帶 profiling 的 queue 取事件時間，精準反映 DMA
    q_prof = cl.CommandQueue(ctx, properties=cl.command_queue_properties.PROFILING_ENABLE)

    def _gbps(evt):
        evt.wait()
        t = (evt.profile.end - evt.profile.start) * 1e-9  # ns → s
        return bytes_len / t / 1e9

    h2d, d2h = [], []
    for _ in range(trials):
        e = cl.enqueue_copy(q_prof, dev_buf, host_buf); h2d.append(_gbps(e))
        e = cl.enqueue_copy(q_prof, host_buf, dev_buf); d2h.append(_gbps(e))

    if hasattr(host_buf, "enqueue_unmap"):
        event = host_buf.enqueue_unmap(queue, host_arr)
        event.wait()
    else:
        queue.finish()

    H2D, D2H = _median(h2d), _median(d2h)
    eff = min(H2D, D2H)
    cls = _classify_link(eff)
    return {
        "mode": "pinned",
        "device": dev.name,
        "platform": dev.platform.name,
        "pci_bus": _get_pci_bus_info(dev),
        "H2D_GBps": H2D,
        "D2H_GBps": D2H,
        "effective_GBps": eff,
        "class": cls,
        "suggest": _suggest_stripe_and_code(eff),
    }

# ---- CLI ----
def main():
    ap = argparse.ArgumentParser(description="RetryIX PCIe Probe (SVM & Pinned)")
    ap.add_argument("--mode", choices=["svm", "pinned", "both"], default="both")
    ap.add_argument("--svm-bytes", type=int, default=SVM_BYTES)
    ap.add_argument("--pinned-bytes", type=int, default=PINNED_BYTES)
    ap.add_argument("--trials", type=int, default=TRIALS)
    ap.add_argument("--keepalive-bytes", type=int, default=KEEPALIVE_BYTES)
    args = ap.parse_args()

    if args.mode in ("svm", "both"):
        r = measure_svm_pcie_gbps(args.svm_bytes, args.trials, args.keepalive_bytes)
        s_kb, code = r["suggest"]
        print(f"[SVM]    H2D {r['H2D_GBps']:.2f} GB/s, D2H {r['D2H_GBps']:.2f} GB/s → {r['class']} "
              f"(Device={r['device']}, Platform={r['platform']}, Bus={r['pci_bus']})")
        print(f"         ↳ 建議: stripe={s_kb//1024}KB, code={code}")

    if args.mode in ("pinned", "both"):
        r = measure_pinned_pcie_gbps(args.pinned_bytes, args.trials, args.keepalive_bytes, cl)
        s_kb, code = r["suggest"]
        print(f"[Pinned] H2D {r['H2D_GBps']:.2f} GB/s, D2H {r['D2H_GBps']:.2f} GB/s → {r['class']} "
              f"(Device={r['device']}, Platform={r['platform']}, Bus={r['pci_bus']})")
        print(f"         ↳ 建議: stripe={s_kb//1024}KB, code={code}")

if __name__ == "__main__":
    main()
