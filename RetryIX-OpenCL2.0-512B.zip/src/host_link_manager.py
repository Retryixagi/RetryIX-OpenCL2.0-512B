# host_link_manager.py
# Fixed as Gen4 x16 (~28 GB/s) minimal module
# No background thread, no new SVM/Context/Queue; only use the caller's svm_mgr

from typing import Optional, Tuple
import numpy as np
import pyopencl as cl

def _suggest(eff_gbps: float) -> Tuple[int, str]:
    # Suggest stripe size / code according to effective bandwidth
    if eff_gbps < 7:    return 128*1024, "LRC"
    if eff_gbps < 14:   return 256*1024, "LRC"
    if eff_gbps < 28:   return 512*1024, "LRC_RS_MIX"
    return 1*1024*1024, "RS"

class HostLinkManager:
    """
    Fixed x16/Gen4 scenario:
      - initialize(): directly uses baseline_gbps (default 28.0) as fixed bandwidth
      - kick(): does nothing by default; if keepalive=True, sends a very small non-blocking copy
      - close(): releases any keepalive buffer if created
    """
    def __init__(self,
                 svm_mgr,
                 baseline_gbps: float = 28.0,        # fixed as Gen4 x16 effective bandwidth
                 keepalive: bool = False,            # default disabled, since power saving is off
                 keepalive_bytes: int = 256*1024):   # small packet size when keepalive is enabled
        if svm_mgr is None:
            raise RuntimeError("svm_mgr is required")
        self.svm_mgr = svm_mgr
        self.ctx: cl.Context = svm_mgr.context
        self.queue: cl.CommandQueue = svm_mgr.queue
        self.dev: cl.Device = svm_mgr.device

        self.baseline_gbps = baseline_gbps
        self.keepalive = keepalive
        self.keepalive_bytes = keepalive_bytes

        self._mf = cl.mem_flags
        self._dev_keep = None
        self._host_keep = None
        self._host_keep_arr = None

        # Set by initialize()
        self.suggest_plan: Optional[Tuple[int, str]] = None

    def initialize(self):
        """Always use baseline_gbps as x16 bandwidth and calculate suggested stripe/code."""
        eff = self.baseline_gbps
        self.suggest_plan = _suggest(eff)
        # Can be passed externally to BlockAlignmentOptimizer
        print(f"HostLink: fixed Gen4 x16, baseline={eff:.2f} GB/s "
              f"(stripe={self.suggest_plan[0]//1024}KB, code={self.suggest_plan[1]})")
        # Allocate keepalive buffers only if needed
        if self.keepalive and self._dev_keep is None:
            self._alloc_keepalive_buffers()
        return {"effective_GBps": eff, "suggest": self.suggest_plan, "device": self.dev.name}

    def kick(self):
        """Do nothing by default; only send a non-blocking small packet if keepalive=True."""
        if not self.keepalive or self._dev_keep is None:
            return
        cl.enqueue_copy(self.queue, self._dev_keep, self._host_keep, is_blocking=False)

    def close(self):
        """Release keepalive buffers."""
        if self._host_keep_arr is not None:
            cl.enqueue_unmap_mem_object(self.queue, self._host_keep, self._host_keep_arr).wait()
        for buf in (self._dev_keep, self._host_keep):
            try:
                if buf is not None:
                    buf.release()
            except Exception:
                pass
        self._dev_keep = self._host_keep = None
        self._host_keep_arr = None

    # -------- Internal --------
    def _alloc_keepalive_buffers(self):
        self._dev_keep  = cl.Buffer(self.ctx, self._mf.READ_WRITE, size=self.keepalive_bytes)
        self._host_keep = cl.Buffer(self.ctx, self._mf.ALLOC_HOST_PTR | self._mf.READ_WRITE,
                                    size=self.keepalive_bytes)
        self._host_keep_arr, _ = cl.enqueue_map_buffer(
            self.queue, self._host_keep, cl.map_flags.WRITE, 0,
            (self.keepalive_bytes,), np.uint8, is_blocking=True
        )
        self._host_keep_arr[:] = 1
