# host_link_manager.py
# 固定視為 Gen4 x16（約 28 GB/s）的最簡模塊
# 無背景執行緒、不新建 SVM/Context/Queue；只用呼叫者給的 svm_mgr

from typing import Optional, Tuple
import numpy as np
import pyopencl as cl

def _suggest(eff_gbps: float) -> Tuple[int, str]:
    # 依有效帶寬給條帶/編碼建議（與你現用邏輯一致）
    if eff_gbps < 7:    return 128*1024, "LRC"
    if eff_gbps < 14:   return 256*1024, "LRC"
    if eff_gbps < 28:   return 512*1024, "LRC_RS_MIX"
    return 1*1024*1024, "RS"

class HostLinkManager:
    """
    固定 x16/Gen4 場景使用：
      - initialize(): 直接採用 baseline_gbps（預設 28.0）作為固定帶寬
      - kick(): 預設什麼都不做；如果 keepalive=True，才會丟一個很小的非阻塞 copy
      - close(): 釋放可能建立的 keepalive 緩衝
    """
    def __init__(self,
                 svm_mgr,
                 baseline_gbps: float = 28.0,        # 固定視為 Gen4 x16 實效
                 keepalive: bool = False,            # 預設不用，因你已關省電
                 keepalive_bytes: int = 256*1024):   # 需要時的小包大小
        if svm_mgr is None:
            raise RuntimeError("svm_mgr is required")
        self.svm_mgr = svm_mgr
        self.ctx: cl.Context = svm_mgr.context
        self.queue: cl.CommandQueue = svm_mgr.queue
        self.dev: cl.Device = svm_mgr.device

        self.baseline_gbps = baseline_gbps
        self.keepalive = keepalive
        self.keepalive_bytes = keepalive_bytes

        self._mf = cl.mem_flags
        self._dev_keep = None
        self._host_keep = None
        self._host_keep_arr = None

        # 由 initialize() 設定
        self.suggest_plan: Optional[Tuple[int, str]] = None

    def initialize(self):
        """固定採用 baseline_gbps 作為 x16 帶寬，計算建議條帶/編碼。"""
        eff = self.baseline_gbps
        self.suggest_plan = _suggest(eff)
        # 可在外部把 eff/plan 餵進你的 BlockAlignmentOptimizer
        print(f"🔗 HostLink: fixed Gen4 x16, baseline={eff:.2f} GB/s "
              f"(stripe={self.suggest_plan[0]//1024}KB, code={self.suggest_plan[1]})")
        # 如需 keepalive，這裡才配緩衝（不影響其他模塊）
        if self.keepalive and self._dev_keep is None:
            self._alloc_keepalive_buffers()
        return {"effective_GBps": eff, "suggest": self.suggest_plan, "device": self.dev.name}

    def kick(self):
        """預設不做任何事；只有 keepalive=True 時才丟一個非阻塞小包。"""
        if not self.keepalive or self._dev_keep is None:
            return
        cl.enqueue_copy(self.queue, self._dev_keep, self._host_keep, is_blocking=False)

    def close(self):
        """釋放 keepalive 緩衝。"""
        if self._host_keep_arr is not None:
            cl.enqueue_unmap_mem_object(self.queue, self._host_keep, self._host_keep_arr).wait()
        for buf in (self._dev_keep, self._host_keep):
            try:
                if buf is not None: buf.release()
            except Exception:
                pass
        self._dev_keep = self._host_keep = None
        self._host_keep_arr = None

    # -------- 內部 --------
    def _alloc_keepalive_buffers(self):
        self._dev_keep  = cl.Buffer(self.ctx, self._mf.READ_WRITE, size=self.keepalive_bytes)
        self._host_keep = cl.Buffer(self.ctx, self._mf.ALLOC_HOST_PTR | self._mf.READ_WRITE,
                                    size=self.keepalive_bytes)
        self._host_keep_arr, _ = cl.enqueue_map_buffer(
            self.queue, self._host_keep, cl.map_flags.WRITE, 0,
            (self.keepalive_bytes,), np.uint8, is_blocking=True
        )
        self._host_keep_arr[:] = 1
