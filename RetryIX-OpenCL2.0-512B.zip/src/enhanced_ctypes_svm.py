#!/usr/bin/env python3
"""
改进版OpenCL SVM管理器 - 完全優化版本
修正库加载机制，避免DLL搜索优先级问题
遵循标准ICD机制，提高稳定性和可移植性
整合監控和性能優化功能
"""

import os
import ctypes
from ctypes import c_void_p, c_size_t, c_uint, c_int, c_ulong, POINTER
import platform
import numpy as np
import pyopencl as cl
import time
import subprocess
import sys
from typing import Optional, Dict, Any, List, Union, Tuple
import warnings
import winreg
from pathlib import Path
import logging
from collections import defaultdict, deque
import psutil

# 設置日誌
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# OpenCL 常数
CL_SUCCESS = 0
CL_MEM_READ_WRITE = 1 << 0
CL_MEM_SVM_FINE_GRAIN_BUFFER = 1 << 10
CL_MAP_READ = 1 << 0
CL_MAP_WRITE = 1 << 1

class OpenCLEnvironmentManager:
    """OpenCL环境管理器 - 负责合理的库发现和加载"""
    
    def __init__(self):
        self.system = platform.system()
        self.arch = platform.architecture()[0]
        self.debug_mode = os.getenv('OPENCL_DEBUG', '0') == '1'
        
    def setup_opencl_environment(self) -> Dict[str, Any]:
        """设置OpenCL环境，优先使用ICD机制"""
        env_info = {
            'icd_available': False,
            'vendors_found': [],
            'library_path': None,
            'warnings': [],
            'environment_vars': {},
            'system_info': {
                'platform': self.system,
                'architecture': self.arch,
                'python_version': sys.version,
                'pyopencl_version': cl.version.VERSION_TEXT if hasattr(cl.version, 'VERSION_TEXT') else 'unknown'
            }
        }
        
        # 1. 检查并设置环境变量
        self._setup_environment_variables(env_info)
        
        # 2. 验证ICD机制
        self._check_icd_mechanism(env_info)
        
        # 3. 查找可用厂商
        self._discover_opencl_vendors(env_info)
        
        # 4. 系統資源檢測
        self._check_system_resources(env_info)
        
        if self.debug_mode:
            self._print_environment_info(env_info)
            
        return env_info
    
    def _setup_environment_variables(self, env_info: Dict):
        """设置OpenCL相关环境变量"""
        
        # 检查用户自定义路径
        custom_path = os.getenv('OPENCL_VENDOR_PATH')
        if custom_path:
            env_info['environment_vars']['OPENCL_VENDOR_PATH'] = custom_path
            
        # 检查PyOpenCL特定设置
        pyocl_ctx = os.getenv('PYOPENCL_CTX')
        if pyocl_ctx:
            env_info['environment_vars']['PYOPENCL_CTX'] = pyocl_ctx
            
        # Windows特定：检查并设置DLL搜索路径
        if self.system == "Windows":
            self._setup_windows_dll_path(env_info)
    
    def _setup_windows_dll_path(self, env_info: Dict):
        """Windows专用：安全设置DLL搜索路径"""
        try:
            # 检查是否存在本地bin目录
            bin_path = Path("bin").resolve()
            if bin_path.exists():
                # 使用Python 3.8+的安全DLL目录机制
                if hasattr(os, 'add_dll_directory'):
                    os.add_dll_directory(str(bin_path))
                    env_info['warnings'].append(
                        f"已添加本地DLL目录: {bin_path} (仅用于开发测试)"
                    )
                else:
                    # 对于旧版本Python，修改PATH但发出警告
                    original_path = os.environ.get('PATH', '')
                    os.environ['PATH'] = f"{bin_path};{original_path}"
                    env_info['warnings'].append(
                        "警告: 使用了PATH修改方式加载本地DLL，建议升级到Python 3.8+"
                    )
        except Exception as e:
            env_info['warnings'].append(f"设置Windows DLL路径时出错: {e}")
    
    def _check_icd_mechanism(self, env_info: Dict):
        """检查OpenCL ICD机制是否正常工作"""
        try:
            if self.system == "Windows":
                self._check_windows_icd(env_info)
            elif self.system == "Linux":
                self._check_linux_icd(env_info)
            elif self.system == "Darwin":
                self._check_macos_icd(env_info)
                
        except Exception as e:
            env_info['warnings'].append(f"检查ICD机制时出错: {e}")
    
    def _check_windows_icd(self, env_info: Dict):
        """检查Windows的OpenCL ICD注册表"""
        try:
            # 检查64位注册表
            reg_paths = [
                r"SOFTWARE\Khronos\OpenCL\Vendors",
                r"SOFTWARE\WOW6432Node\Khronos\OpenCL\Vendors",
                r"SOFTWARE\RetryIX\Core"
            ]
            
            vendors_found = []
            for reg_path in reg_paths:
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path) as key:
                        i = 0
                        while True:
                            try:
                                vendor_dll, _ = winreg.EnumValue(key, i)
                                if os.path.exists(vendor_dll):
                                    vendor_name = self._identify_vendor_from_path(vendor_dll)
                                    vendors_found.append({
                                        'name': vendor_name,
                                        'dll_path': vendor_dll,
                                        'registry_path': reg_path,
                                        'file_size': os.path.getsize(vendor_dll),
                                        'modified_time': os.path.getmtime(vendor_dll)
                                    })
                                i += 1
                            except WindowsError:
                                break
                except FileNotFoundError:
                    continue
            
            if vendors_found:
                env_info['icd_available'] = True
                env_info['vendors_found'] = vendors_found
                logger.debug(f"Windows ICD檢測到 {len(vendors_found)} 個廠商")
            else:
                env_info['warnings'].append("Windows注册表中未找到OpenCL厂商")
                
        except Exception as e:
            env_info['warnings'].append(f"检查Windows ICD失败: {e}")
    
    def _check_linux_icd(self, env_info: Dict):
        """检查Linux的OpenCL ICD配置"""
        icd_paths = [
            "/etc/OpenCL/vendors",
            "/usr/share/OpenCL/vendors",
            "/usr/local/share/OpenCL/vendors",
            "/opt/intel/opencl/vendors"  # Intel特定路徑
        ]
        
        vendors_found = []
        for icd_path in icd_paths:
            if os.path.exists(icd_path):
                for icd_file in os.listdir(icd_path):
                    if icd_file.endswith('.icd'):
                        icd_full_path = os.path.join(icd_path, icd_file)
                        try:
                            with open(icd_full_path, 'r') as f:
                                vendor_lib = f.read().strip()
                                if os.path.exists(vendor_lib):
                                    vendor_name = self._identify_vendor_from_path(vendor_lib)
                                    vendors_found.append({
                                        'name': vendor_name,
                                        'lib_path': vendor_lib,
                                        'icd_file': icd_full_path,
                                        'file_size': os.path.getsize(vendor_lib),
                                        'modified_time': os.path.getmtime(vendor_lib)
                                    })
                        except Exception:
                            continue
        
        if vendors_found:
            env_info['icd_available'] = True
            env_info['vendors_found'] = vendors_found
            logger.debug(f"Linux ICD檢測到 {len(vendors_found)} 個廠商")
        else:
            env_info['warnings'].append("Linux ICD目录中未找到有效厂商")
    
    def _check_macos_icd(self, env_info: Dict):
        """检查macOS的OpenCL框架"""
        framework_path = "/System/Library/Frameworks/OpenCL.framework/OpenCL"
        if os.path.exists(framework_path):
            env_info['icd_available'] = True
            env_info['vendors_found'] = [{
                'name': 'Apple',
                'framework_path': framework_path,
                'file_size': os.path.getsize(framework_path),
                'modified_time': os.path.getmtime(framework_path)
            }]
            logger.debug("macOS OpenCL框架檢測成功")
        else:
            env_info['warnings'].append("macOS OpenCL框架未找到")
    
    def _check_system_resources(self, env_info: Dict):
        """檢查系統資源"""
        try:
            # 記憶體信息
            memory = psutil.virtual_memory()
            env_info['system_resources'] = {
                'total_memory_gb': memory.total / (1024**3),
                'available_memory_gb': memory.available / (1024**3),
                'cpu_count': psutil.cpu_count(),
                'cpu_freq_mhz': psutil.cpu_freq().current if psutil.cpu_freq() else 0
            }
        except Exception as e:
            env_info['warnings'].append(f"系統資源檢測失敗: {e}")
    
    def _identify_vendor_from_path(self, path: str) -> str:
        """从路径识别厂商"""
        path_lower = path.lower()
        if 'amd' in path_lower or 'ati' in path_lower:
            return 'AMD'
        elif 'nvidia' in path_lower or 'nvopencl' in path_lower:
            return 'NVIDIA'  
        elif 'intel' in path_lower:
            return 'Intel'
        elif 'apple' in path_lower:
            return 'Apple'
        elif 'mesa' in path_lower:
            return 'Mesa'
        else:
            return 'Unknown'
    
    def _discover_opencl_vendors(self, env_info: Dict):
        """发现可用的OpenCL厂商（补充ICD机制）"""
        if env_info['icd_available']:
            return  # ICD机制工作正常，不需要额外发现
        
        # ICD不可用时的备用发现机制
        fallback_paths = self._get_fallback_library_paths()
        
        for lib_path in fallback_paths:
            try:
                if self.system == "Windows":
                    # 尝试加载但不保持引用
                    lib = ctypes.windll.LoadLibrary(lib_path)
                    vendor_name = self._identify_vendor_from_path(lib_path)
                    env_info['vendors_found'].append({
                        'name': vendor_name,
                        'lib_path': lib_path,
                        'fallback': True
                    })
                else:
                    lib = ctypes.CDLL(lib_path)
                    vendor_name = self._identify_vendor_from_path(lib_path)
                    env_info['vendors_found'].append({
                        'name': vendor_name,
                        'lib_path': lib_path,
                        'fallback': True
                    })
            except OSError:
                continue
    
    def _get_fallback_library_paths(self) -> List[str]:
        """获取备用库路径"""
        if self.system == "Windows":
            return [
                "retryix.dll"  # 系统标准ICD加载器
            ]
        elif self.system == "Linux":
            return [
                "libOpenCL.so.1",
                "libOpenCL.so",
                "/usr/lib/x86_64-linux-gnu/libOpenCL.so.1",
                "/usr/lib64/libOpenCL.so.1",
                "/usr/local/lib/libOpenCL.so.1"
            ]
        elif self.system == "Darwin":
            return ["/System/Library/Frameworks/OpenCL.framework/OpenCL"]
        else:
            return []
    
    def _print_environment_info(self, env_info: Dict):
        """打印环境信息（调试模式）"""
        logger.info("🔍 OpenCL环境詳細信息:")
        logger.info(f"   系統: {self.system} ({self.arch})")
        logger.info(f"   ICD可用: {env_info['icd_available']}")
        logger.info(f"   發現廠商數: {len(env_info['vendors_found'])}")
        
        for vendor in env_info['vendors_found']:
            logger.info(f"     - {vendor['name']}: {vendor}")
            
        if 'system_resources' in env_info:
            res = env_info['system_resources']
            logger.info(f"   系統資源:")
            logger.info(f"     總記憶體: {res['total_memory_gb']:.1f} GB")
            logger.info(f"     可用記憶體: {res['available_memory_gb']:.1f} GB")
            logger.info(f"     CPU核心數: {res['cpu_count']}")
            
        if env_info['warnings']:
            logger.warning("   警告:")
            for warning in env_info['warnings']:
                logger.warning(f"     ⚠️ {warning}")

class ImprovedOpenCLLibraryLoader:
    """改进的OpenCL库加载器 - 遵循ICD标准"""
    
    def __init__(self):
        self.lib = None
        self.env_manager = OpenCLEnvironmentManager()
        self.env_info = None
        self._load_opencl_library()
    
    def _load_opencl_library(self):
        """智能加载OpenCL库"""
        # 设置环境
        self.env_info = self.env_manager.setup_opencl_environment()
        
        # 策略1：优先使用系统ICD加载器
        if self._try_load_system_icd():
            return
            
        # 策略2：直接PyOpenCL检测
        if self._try_pyopencl_detection():
            return
            
        # 策略3：备用直接加载
        if self._try_fallback_loading():
            return
            
        # 所有策略都失败
        self._handle_loading_failure()
    
    def _try_load_system_icd(self) -> bool:
        """尝试加载系统ICD加载器"""
        try:
            if self.env_manager.system == "Windows":
                # Windows优先使用系统OpenCL.dll（ICD加载器）
                self.lib = ctypes.windll.OpenCL
                logger.info("✅ 使用Windows系统ICD加载器")
                self.env_info['icd_available'] = True  # 修正顯示邏輯
                return True
            elif self.env_manager.system == "Linux":
                # Linux使用标准libOpenCL.so
                self.lib = ctypes.CDLL("libOpenCL.so.1")
                logger.info("✅ 使用Linux系统ICD加载器")
                self.env_info['icd_available'] = True
                return True
            elif self.env_manager.system == "Darwin":
                # macOS使用框架
                framework_path = "/System/Library/Frameworks/OpenCL.framework/OpenCL"
                self.lib = ctypes.CDLL(framework_path)
                logger.info("✅ 使用macOS OpenCL框架")
                self.env_info['icd_available'] = True
                return True
        except OSError as e:
            if self.env_manager.debug_mode:
                logger.debug(f"🔍 系统ICD加载失败: {e}")
            return False
        
        return False
    
    def _try_pyopencl_detection(self) -> bool:
        """通过PyOpenCL检测OpenCL可用性"""
        try:
            # 让PyOpenCL自己检测和加载
            platforms = cl.get_platforms()
            if platforms:
                # PyOpenCL成功，尝试获取其使用的库
                self.lib = self._extract_lib_from_pyopencl()
                if self.lib:
                    logger.info("✅ 通过PyOpenCL检测到OpenCL库")
                    return True
        except Exception as e:
            if self.env_manager.debug_mode:
                logger.debug(f"🔍 PyOpenCL检测失败: {e}")
            return False
        
        return False
    
    def _extract_lib_from_pyopencl(self):
        """从PyOpenCL中提取底层库引用"""
        try:
            # 这是一个高级技巧，尝试从PyOpenCL获取底层库
            if hasattr(cl, '_lib'):
                return cl._lib
            
            # 备用方法：通过平台对象获取
            platform = cl.get_platforms()[0]
            if hasattr(platform, '_lib'):
                return platform._lib
                
            # 如果无法直接获取，使用标准加载方式
            if self.env_manager.system == "Windows":
                return ctypes.windll.OpenCL
            else:
                return ctypes.CDLL("libOpenCL.so.1")
                
        except Exception:
            return None
    
    def _try_fallback_loading(self) -> bool:
        """备用加载方式"""
        if not self.env_info['vendors_found']:
            return False
        
        # 尝试加载找到的厂商库
        for vendor in self.env_info['vendors_found']:
            try:
                if 'dll_path' in vendor:
                    lib_path = vendor['dll_path']
                elif 'lib_path' in vendor:
                    lib_path = vendor['lib_path']
                elif 'framework_path' in vendor:
                    lib_path = vendor['framework_path']
                else:
                    continue
                
                if self.env_manager.system == "Windows":
                    self.lib = ctypes.windll.LoadLibrary(lib_path)
                else:
                    self.lib = ctypes.CDLL(lib_path)
                
                fallback_marker = " (備用)" if vendor.get('fallback') else ""
                logger.info(f"✅ 加載{vendor['name']}廠商庫{fallback_marker}: {lib_path}")
                return True
                
            except OSError as e:
                logger.debug(f"嘗試加載 {vendor['name']} 失敗: {e}")
                continue
        
        return False
    
    def _handle_loading_failure(self):
        """处理加载失败"""
        error_msg = "無法加載OpenCL庫。"
        
        if not self.env_info['vendors_found']:
            error_msg += "\n未檢測到任何OpenCL廠商。請安裝顯卡驅動或OpenCL運行時。"
        else:
            error_msg += f"\n檢測到{len(self.env_info['vendors_found'])}個廠商但加載失敗:"
            for vendor in self.env_info['vendors_found']:
                error_msg += f"\n  - {vendor['name']}"
        
        if self.env_info['warnings']:
            error_msg += "\n警告信息:"
            for warning in self.env_info['warnings']:
                error_msg += f"\n  ⚠️ {warning}"
        
        error_msg += "\n\n解決建議:"
        error_msg += "\n1. 檢查顯卡驅動是否正確安裝"
        error_msg += "\n2. 安裝OpenCL運行時 (Intel/AMD/NVIDIA)"
        error_msg += "\n3. 設置環境變量 OPENCL_DEBUG=1 查看詳細信息"
        error_msg += "\n4. 檢查系統架構（32位vs64位）匹配"
        
        raise RuntimeError(error_msg)
    
    def get_environment_info(self) -> Dict[str, Any]:
        """获取环境信息"""
        return self.env_info

class SVMRealityChecker:
    """SVM真實可用性檢測器 - 增強版本"""
    
    def __init__(self, lib_loader: ImprovedOpenCLLibraryLoader):
        self.lib = lib_loader.lib
        self.env_info = lib_loader.get_environment_info()
        self._setup_function_prototypes()
        
        # 已知的問題驅動/平台
        self.problematic_vendors = {
            'apple': "macOS OpenCL SVM支持不穩定",
            'nvidia': "舊版NVIDIA驅動SVM支持有問題", 
            'intel': "某些Intel集成顯卡SVM實現不完整",
            'mesa': "Mesa開源驅動SVM支持有限"
        }
        
        # 性能基準測試參數
        self.benchmark_sizes = [1024, 4096, 16384, 65536]  # 不同大小的測試
        self.performance_results = {}
    
    def _setup_function_prototypes(self):
        """设定OpenCL函数原型"""
        # clSVMAlloc
        self.lib.clSVMAlloc.argtypes = [
            c_void_p,    # context
            c_ulong,     # flags
            c_size_t,    # size
            c_uint       # alignment
        ]
        self.lib.clSVMAlloc.restype = c_void_p
        
        # clSVMFree
        self.lib.clSVMFree.argtypes = [
            c_void_p,    # context
            c_void_p     # svm_pointer
        ]
        self.lib.clSVMFree.restype = None
        
        # clEnqueueSVMMap
        self.lib.clEnqueueSVMMap.argtypes = [
            c_void_p, c_uint, c_ulong, c_void_p, c_size_t,
            c_uint, POINTER(c_void_p), POINTER(c_void_p)
        ]
        self.lib.clEnqueueSVMMap.restype = c_int
        
        # clEnqueueSVMUnmap
        self.lib.clEnqueueSVMUnmap.argtypes = [
            c_void_p, c_void_p, c_uint, POINTER(c_void_p), POINTER(c_void_p)
        ]
        self.lib.clEnqueueSVMUnmap.restype = c_int
    
    def check_vendor_compatibility(self, device: cl.Device) -> Tuple[bool, str]:
        """检查供应商兼容性 - 結合環境信息"""
        vendor = device.vendor.lower()
        
        # 结合环境检测信息
        detected_vendors = [v['name'].lower() for v in self.env_info.get('vendors_found', [])]
        
        for problematic, reason in self.problematic_vendors.items():
            if problematic in vendor:
                # 检查是否在环境中检测到对应厂商
                if problematic in detected_vendors:
                    driver_version = getattr(device, 'driver_version', '')
                    if self._is_known_good_version(vendor, driver_version):
                        return True, f"已知良好版本: {driver_version}"
                    else:
                        return False, f"{reason} (環境檢測確認: {driver_version})"
                else:
                    return False, f"{reason} (環境未檢測到對應廠商)"
        
        return True, "供應商兼容性檢查通過"
    
    def _is_known_good_version(self, vendor: str, driver_version: str) -> bool:
        """检查是否为已知良好版本"""
        known_good = {
            'nvidia': ['470.', '480.', '490.', '510.', '520.', '530.', '540.'],
            'amd': ['21.', '22.', '23.', '24.', '25.'],
            'intel': ['27.', '28.', '29.', '30.', '31.', '32.'],
            'apple': ['14.', '15.']  # macOS版本
        }
        
        for vendor_key in known_good:
            if vendor_key in vendor:
                return any(driver_version.startswith(good_ver) 
                          for good_ver in known_good[vendor_key])
        
        return False
    
    def test_basic_allocation(self, context: cl.Context) -> Tuple[bool, str]:
        """测试基本SVM分配和释放"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            size = 1024  # 1KB测试
            alignment = 64
            
            # 尝试分配
            svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            
            if not svm_ptr:
                return False, "clSVMAlloc返回空指针"
            
            # 立即释放
            self.lib.clSVMFree(ctx_ptr, svm_ptr)
            
            return True, "基本分配測試通過"
            
        except Exception as e:
            return False, f"基本分配測試異常: {e}"
    
    def test_memory_access(self, context: cl.Context) -> Tuple[bool, str]:
        """测试SVM内存读写访问"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            size = 256
            alignment = 64
            
            # 分配SVM内存
            svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            if not svm_ptr:
                return False, "分配失敗"
            
            try:
                # 创建ctypes数组来测试读写
                test_data = (ctypes.c_uint8 * size).from_address(svm_ptr)
                
                # 写入测试模式
                test_pattern = [i % 256 for i in range(size)]
                for i, val in enumerate(test_pattern):
                    test_data[i] = val
                
                # 读回验证
                for i, expected in enumerate(test_pattern):
                    if test_data[i] != expected:
                        return False, f"數據不一致在位置{i}: 期望{expected}, 實際{test_data[i]}"
                
                return True, "記憶體存取測試通過"
                
            finally:
                self.lib.clSVMFree(ctx_ptr, svm_ptr)
                
        except Exception as e:
            return False, f"記憶體存取測試異常: {e}"
    
    def test_performance_benchmark(self, context: cl.Context) -> Tuple[bool, str]:
        """性能基準測試"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            alignment = 64
            
            performance_data = {}
            
            for size in self.benchmark_sizes:
                # 分配測試
                start_time = time.time()
                svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
                alloc_time = time.time() - start_time
                
                if not svm_ptr:
                    continue
                
                try:
                    # 寫入測試
                    test_data = (ctypes.c_uint8 * size).from_address(svm_ptr)
                    
                    start_time = time.time()
                    for i in range(size):
                        test_data[i] = i % 256
                    write_time = time.time() - start_time
                    
                    # 讀取測試
                    start_time = time.time()
                    checksum = sum(test_data[i] for i in range(0, size, 64))  # 抽樣檢查
                    read_time = time.time() - start_time
                    
                    performance_data[size] = {
                        'alloc_time': alloc_time * 1000,  # 毫秒
                        'write_time': write_time * 1000,
                        'read_time': read_time * 1000,
                        'write_bandwidth': size / write_time / 1024 / 1024,  # MB/s
                        'read_bandwidth': (size / 64) / read_time / 1024 / 1024  # 抽樣帶寬
                    }
                    
                finally:
                    self.lib.clSVMFree(ctx_ptr, svm_ptr)
            
            self.performance_results = performance_data
            
            if performance_data:
                avg_write_bw = sum(d['write_bandwidth'] for d in performance_data.values()) / len(performance_data)
                return True, f"性能測試通過，平均寫入帶寬: {avg_write_bw:.1f} MB/s"
            else:
                return False, "性能測試：所有大小的分配都失敗"
                
        except Exception as e:
            return False, f"性能測試異常: {e}"
    
    def test_stress_allocation(self, context: cl.Context) -> Tuple[bool, str]:
        """壓力分配測試"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            alignment = 64
            
            # 嘗試分配多個不同大小的緩衝區
            allocated_ptrs = []
            total_allocated = 0
            
            # 分配策略：從小到大，測試記憶體碎片處理
            test_sizes = [1024, 4096, 16384, 65536, 262144]  # 1KB到256KB
            
            for size in test_sizes:
                for i in range(5):  # 每個大小分配5個
                    svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
                    if svm_ptr:
                        allocated_ptrs.append(svm_ptr)
                        total_allocated += size
                    else:
                        break
            
            if not allocated_ptrs:
                return False, "壓力測試：無法分配任何緩衝區"
            
            # 釋放所有緩衝區
            for ptr in allocated_ptrs:
                self.lib.clSVMFree(ctx_ptr, ptr)
            
            return True, f"壓力測試通過：成功分配 {len(allocated_ptrs)} 個緩衝區，總計 {total_allocated/1024:.1f} KB"
            
        except Exception as e:
            return False, f"壓力測試異常: {e}"
    
    def run_comprehensive_test(self, context: cl.Context, queue: cl.CommandQueue) -> Dict[str, Any]:
        """运行综合SVM可用性测试 - 增強版本"""
        results = {
            'vendor_check': False,
            'basic_allocation': False,
            'memory_access': False,
            'performance_benchmark': False,
            'stress_allocation': False,
            'environment_info': self.env_info,
            'overall_usable': False,
            'performance_data': {},
            'messages': [],
            'recommendations': []
        }
        
        device = queue.device
        
        # 1. 供應商兼容性檢查
        vendor_ok, vendor_msg = self.check_vendor_compatibility(device)
        results['vendor_check'] = vendor_ok
        results['messages'].append(f"供應商檢查: {vendor_msg}")
        
        if not vendor_ok:
            results['messages'].append("⚠️ 供應商兼容性問題，但繼續測試...")
            results['recommendations'].append("考慮更新顯卡驅動到最新版本")
        
        # 2. 基本分配測試
        alloc_ok, alloc_msg = self.test_basic_allocation(context)
        results['basic_allocation'] = alloc_ok
        results['messages'].append(f"基本分配: {alloc_msg}")
        
        if not alloc_ok:
            results['messages'].append("❌ 基本分配失敗，停止後續測試")
            results['recommendations'].append("檢查OpenCL驅動安裝是否完整")
            return results
        
        # 3. 記憶體存取測試
        access_ok, access_msg = self.test_memory_access(context)
        results['memory_access'] = access_ok
        results['messages'].append(f"記憶體存取: {access_msg}")
        
        if not access_ok:
            results['recommendations'].append("記憶體存取問題，可能是硬體相關")
        
        # 4. 性能基準測試
        perf_ok, perf_msg = self.test_performance_benchmark(context)
        results['performance_benchmark'] = perf_ok
        results['messages'].append(f"性能測試: {perf_msg}")
        results['performance_data'] = self.performance_results
        
        if perf_ok:
            # 分析性能結果
            if self.performance_results:
                largest_size = max(self.performance_results.keys())
                largest_perf = self.performance_results[largest_size]
                if largest_perf['write_bandwidth'] < 100:  # MB/s
                    results['recommendations'].append("SVM寫入性能較低，考慮使用較小緩衝區")
        
        # 5. 壓力分配測試
        stress_ok, stress_msg = self.test_stress_allocation(context)
        results['stress_allocation'] = stress_ok
        results['messages'].append(f"壓力測試: {stress_msg}")
        
        if not stress_ok:
            results['recommendations'].append("壓力測試失敗，避免大量同時分配")
        
        # 綜合評估
        critical_tests = [alloc_ok, access_ok]
        important_tests = [perf_ok, stress_ok]
        
        results['overall_usable'] = all(critical_tests) and any(important_tests)
        
        if results['overall_usable']:
            results['messages'].append("✅ SVM綜合測試通過，實際可用")
            
            # 額外建議
            if vendor_ok and perf_ok and stress_ok:
                results['recommendations'].append("SVM性能良好，建議用於高性能計算")
            elif not stress_ok:
                results['recommendations'].append("避免過度分配，建議使用記憶體池")
        else:
            failed_tests = []
            if not alloc_ok: failed_tests.append("分配")
            if not access_ok: failed_tests.append("存取")
            if not perf_ok: failed_tests.append("性能")
            if not stress_ok: failed_tests.append("壓力")
            results['messages'].append(f"❌ SVM不可用，失敗測試: {', '.join(failed_tests)}")
            results['recommendations'].append("建議使用傳統OpenCL緩衝區替代SVM")
        
        return results

class EnhancedSVMCapabilityChecker:
    """增强版SVM能力检测器 - 集成改进的库加载"""
    
    @staticmethod
    def check_svm_support(device: cl.Device, do_reality_check: bool = True) -> Dict[str, Any]:
        """检查设备的SVM支持能力（使用改进的库加载）"""
        capabilities = {
            'has_svm': False,
            'coarse_grain_buffer': False,
            'fine_grain_buffer': False,
            'fine_grain_system': False,
            'atomics': False,
            'reality_tested': False,
            'actually_usable': False,
            'test_results': {},
            'warnings': [],
            'device_info': {
                'name': device.name,
                'vendor': device.vendor,
                'version': device.opencl_c_version,
                'driver_version': getattr(device, 'driver_version', 'unknown'),
                'max_memory': device.max_mem_alloc_size,
                'global_memory': device.global_mem_size
            }
        }
        
        try:
            # 检查基本SVM支持
            svm_caps = device.svm_capabilities
            
            if svm_caps:
                capabilities['has_svm'] = True
                
                # 检查具体能力
                if svm_caps & cl.device_svm_capabilities.COARSE_GRAIN_BUFFER:
                    capabilities['coarse_grain_buffer'] = True
                
                if svm_caps & cl.device_svm_capabilities.FINE_GRAIN_BUFFER:
                    capabilities['fine_grain_buffer'] = True
                
                if svm_caps & cl.device_svm_capabilities.FINE_GRAIN_SYSTEM:
                    capabilities['fine_grain_system'] = True
                
                if svm_caps & cl.device_svm_capabilities.ATOMICS:
                    capabilities['atomics'] = True
        
        except (AttributeError, cl.LogicError):
            capabilities['warnings'].append("設備不報告SVM能力")
        
        # 进行底层实测（使用改进的库加载器）
        if do_reality_check and capabilities['has_svm']:
            try:
                context = cl.Context([device])
                queue = cl.CommandQueue(context)
                
                # 使用改进的库加载器
                lib_loader = ImprovedOpenCLLibraryLoader()
                reality_checker = SVMRealityChecker(lib_loader)
                
                test_results = reality_checker.run_comprehensive_test(context, queue)
                
                capabilities['reality_tested'] = True
                capabilities['actually_usable'] = test_results['overall_usable']
                capabilities['test_results'] = test_results
                
                # 收集环境信息
                capabilities['environment_info'] = test_results['environment_info']
                
                # 收集警告信息
                if not test_results['vendor_check']:
                    capabilities['warnings'].append("供應商兼容性問題")
                
                if capabilities['has_svm'] and not capabilities['actually_usable']:
                    capabilities['warnings'].append("聲稱支持SVM但實測失敗")
                
                # 添加性能建議
                if 'performance_data' in test_results and test_results['performance_data']:
                    capabilities['performance_summary'] = test_results['performance_data']
                
                if 'recommendations' in test_results:
                    capabilities['recommendations'] = test_results['recommendations']
                
            except Exception as e:
                capabilities['warnings'].append(f"實測過程異常: {e}")
                capabilities['reality_tested'] = False
        
        return capabilities

class ImprovedSVMManager:
    """改进的SVM管理器 - 使用新的库加载机制和性能監控"""
    
    def __init__(self, context: cl.Context, queue: cl.CommandQueue, 
                 skip_reality_check: bool = False):
        self.context = context
        self.queue = queue
        self.device = queue.device
        
        # 检查SVM支持（使用改进的检测器）
        self.svm_capabilities = EnhancedSVMCapabilityChecker.check_svm_support(
            self.device, do_reality_check=not skip_reality_check
        )
        
        # 严格验证
        if not self.svm_capabilities['has_svm']:
            raise RuntimeError(f"設備 {self.device.name} 不支持SVM")
        
        if not skip_reality_check:
            if not self.svm_capabilities['actually_usable']:
                warnings_msg = "; ".join(self.svm_capabilities['warnings'])
                raise RuntimeError(
                    f"設備 {self.device.name} 聲稱支持SVM，但底層實測失敗。"
                    f"原因: {warnings_msg}"
                )
        
        # 使用改进的库加载器
        try:
            self.lib_loader = ImprovedOpenCLLibraryLoader()
            self._lib = self.lib_loader.lib
            self._setup_function_prototypes()
        except RuntimeError as e:
            raise RuntimeError(f"SVM初始化失敗: {e}")
        
        # SVM缓冲区管理
        self.svm_buffers = {}
        self.next_buffer_id = 0
        
        # 性能監控
        self.allocation_stats = {
            'total_allocations': 0,
            'total_deallocations': 0,
            'current_allocated_bytes': 0,
            'peak_allocated_bytes': 0,
            'allocation_times': deque(maxlen=100),
            'deallocation_times': deque(maxlen=100),
            'failed_allocations': 0
        }
        
        # 打印初始化信息
        logger.info(f"✅ SVM管理器初始化成功")
        logger.info(f"   設備: {self.device.name}")
        
        # 显示环境信息
        if 'environment_info' in self.svm_capabilities:
            env_info = self.svm_capabilities['environment_info']
            if env_info and env_info.get('vendors_found'):
                logger.info(f"   檢測到廠商: {[v['name'] for v in env_info['vendors_found']]}")
                logger.info(f"   使用ICD: {'是' if env_info.get('icd_available', False) else '否'}")
        
        if self.svm_capabilities['reality_tested']:
            result = '✅ 可用' if self.svm_capabilities['actually_usable'] else '❌ 不可用'
            logger.info(f"   實測結果: {result}")
            
        # 顯示性能信息
        if 'performance_summary' in self.svm_capabilities:
            perf = self.svm_capabilities['performance_summary']
            if perf:
                largest_size = max(perf.keys())
                largest_perf = perf[largest_size]
                logger.info(f"   性能基準: {largest_perf['write_bandwidth']:.1f} MB/s 寫入帶寬")
        
        # 顯示建議
        if 'recommendations' in self.svm_capabilities:
            for rec in self.svm_capabilities['recommendations'][:2]:  # 只顯示前2個
                logger.info(f"   建議: {rec}")
    
    def _setup_function_prototypes(self):
        """设定OpenCL函数原型"""
        # clSVMAlloc
        self._lib.clSVMAlloc.argtypes = [
            c_void_p,    # context
            c_ulong,     # flags
            c_size_t,    # size
            c_uint       # alignment
        ]
        self._lib.clSVMAlloc.restype = c_void_p
        
        # clSVMFree
        self._lib.clSVMFree.argtypes = [
            c_void_p,    # context
            c_void_p     # svm_pointer
        ]
        self._lib.clSVMFree.restype = None
    
    def allocate(self, size: int, alignment: int = 64, 
                flags: Optional[int] = None, name: Optional[str] = None) -> int:
        """分配SVM内存 - 增強監控"""
        
        start_time = time.time()
        
        if flags is None:
            # 根据设备能力选择最佳flags
            if self.svm_capabilities['fine_grain_buffer']:
                flags = CL_MEM_READ_WRITE | CL_MEM_SVM_FINE_GRAIN_BUFFER
            else:
                flags = CL_MEM_READ_WRITE
        
        try:
            ctx_ptr = c_void_p(int(self.context.int_ptr))
            svm_ptr = self._lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            
            allocation_time = time.time() - start_time
            
            if not svm_ptr:
                self.allocation_stats['failed_allocations'] += 1
                raise RuntimeError(f"SVM分配失敗 (size={size}, flags={flags})")
            
            # 记录缓冲区
            buffer_id = name or f"buffer_{self.next_buffer_id}"
            self.next_buffer_id += 1
            
            self.svm_buffers[buffer_id] = {
                'ptr': svm_ptr,
                'size': size,
                'flags': flags,
                'alignment': alignment,
                'created_at': time.time(),
                'allocation_time': allocation_time
            }
            
            # 更新統計
            self.allocation_stats['total_allocations'] += 1
            self.allocation_stats['current_allocated_bytes'] += size
            self.allocation_stats['peak_allocated_bytes'] = max(
                self.allocation_stats['peak_allocated_bytes'],
                self.allocation_stats['current_allocated_bytes']
            )
            self.allocation_stats['allocation_times'].append(allocation_time * 1000)  # 毫秒
            
            logger.debug(f"✅ SVM分配成功: {buffer_id} ({size} bytes, {allocation_time*1000:.2f}ms)")
            
            return svm_ptr
            
        except Exception as e:
            self.allocation_stats['failed_allocations'] += 1
            logger.error(f"❌ SVM分配失敗: {e}")
            raise
    
    def free(self, svm_ptr: int, name: Optional[str] = None):
        """释放SVM内存 - 增強監控"""
        if not svm_ptr:
            return
            
        start_time = time.time()
        
        try:
            ctx_ptr = c_void_p(int(self.context.int_ptr))
            self._lib.clSVMFree(ctx_ptr, c_void_p(svm_ptr))
            
            deallocation_time = time.time() - start_time
            
            # 從記錄中移除並更新統計
            buffer_info = None
            if name and name in self.svm_buffers:
                buffer_info = self.svm_buffers[name]
                del self.svm_buffers[name]
            else:
                # 按指針查找並移除
                for buffer_name, info in list(self.svm_buffers.items()):
                    if info['ptr'] == svm_ptr:
                        buffer_info = info
                        del self.svm_buffers[buffer_name]
                        break
            
            if buffer_info:
                self.allocation_stats['current_allocated_bytes'] -= buffer_info['size']
                self.allocation_stats['total_deallocations'] += 1
                self.allocation_stats['deallocation_times'].append(deallocation_time * 1000)
                
                logger.debug(f"✅ SVM釋放成功: {name or 'unnamed'} ({deallocation_time*1000:.2f}ms)")
            
        except Exception as e:
            logger.error(f"❌ SVM釋放失敗: {e}")
            raise
    
    def get_device_info(self) -> Dict[str, Any]:
        """获取设备信息 - 增強版本"""
        info = {
            'device_name': self.device.name,
            'device_vendor': self.device.vendor,
            'opencl_version': self.device.opencl_c_version,
            'driver_version': getattr(self.device, 'driver_version', 'unknown'),
            'svm_capabilities': self.svm_capabilities,
            'max_memory_alloc': self.device.max_mem_alloc_size,
            'global_memory': self.device.global_mem_size,
            'allocation_stats': self.allocation_stats.copy(),
            'current_buffers': len(self.svm_buffers)
        }
        
        # 添加环境信息
        if hasattr(self.lib_loader, 'env_info'):
            info['environment_info'] = self.lib_loader.env_info
            
        # 計算統計摘要
        if self.allocation_stats['allocation_times']:
            info['performance_summary'] = {
                'avg_allocation_time_ms': sum(self.allocation_stats['allocation_times']) / len(self.allocation_stats['allocation_times']),
                'max_allocation_time_ms': max(self.allocation_stats['allocation_times']),
                'min_allocation_time_ms': min(self.allocation_stats['allocation_times'])
            }
            
        if self.allocation_stats['deallocation_times']:
            info['performance_summary'].update({
                'avg_deallocation_time_ms': sum(self.allocation_stats['deallocation_times']) / len(self.allocation_stats['deallocation_times']),
                'max_deallocation_time_ms': max(self.allocation_stats['deallocation_times']),
                'min_deallocation_time_ms': min(self.allocation_stats['deallocation_times'])
            })
            
        return info
    
    def get_allocation_stats(self) -> Dict[str, Any]:
        """獲取分配統計詳細信息"""
        stats = self.allocation_stats.copy()
        
        # 計算成功率
        total_attempts = stats['total_allocations'] + stats['failed_allocations']
        if total_attempts > 0:
            stats['success_rate'] = stats['total_allocations'] / total_attempts
        else:
            stats['success_rate'] = 0.0
        
        # 記憶體利用率
        if stats['peak_allocated_bytes'] > 0:
            stats['current_utilization'] = stats['current_allocated_bytes'] / stats['peak_allocated_bytes']
        else:
            stats['current_utilization'] = 0.0
        
        # 平均緩衝區大小
        if self.svm_buffers:
            total_size = sum(buf['size'] for buf in self.svm_buffers.values())
            stats['avg_buffer_size'] = total_size / len(self.svm_buffers)
        else:
            stats['avg_buffer_size'] = 0
        
        return stats
    
    def cleanup(self):
        """清理所有SVM资源 - 增強統計"""
        logger.info("🧹 清理SVM資源...")
        
        cleanup_start = time.time()
        
        # 释放所有注册的缓冲区
        for name, info in list(self.svm_buffers.items()):
            try:
                self.free(info['ptr'], name)
                logger.debug(f"✅ 已釋放SVM緩衝區: {name}")
            except Exception as e:
                logger.error(f"⚠️ 釋放緩衝區 {name} 失敗: {e}")
        
        cleanup_time = time.time() - cleanup_start
        
        # 最終統計報告
        stats = self.get_allocation_stats()
        logger.info(f"📊 SVM使用統計摘要:")
        logger.info(f"   總分配次數: {stats['total_allocations']}")
        logger.info(f"   總釋放次數: {stats['total_deallocations']}")
        logger.info(f"   成功率: {stats['success_rate']:.1%}")
        logger.info(f"   峰值記憶體: {stats['peak_allocated_bytes'] / 1024 / 1024:.1f} MB")
        logger.info(f"   清理時間: {cleanup_time*1000:.1f} ms")
        
        if 'performance_summary' in self.get_device_info():
            perf = self.get_device_info()['performance_summary']
            logger.info(f"   平均分配時間: {perf['avg_allocation_time_ms']:.2f} ms")
        
        self.svm_buffers.clear()
        logger.info("✅ SVM資源清理完成")

def detect_usable_svm_devices(device_type: str = 'gpu', 
                            do_reality_check: bool = True) -> List[Dict[str, Any]]:
    """检测所有实际可用SVM的设备（使用改进的库加载）"""
    usable_devices = []
    
    try:
        platforms = cl.get_platforms()
        
        for platform in platforms:
            logger.info(f"\n🔍 檢查平台: {platform.name}")
            
            try:
                if device_type.lower() == 'gpu':
                    devices = platform.get_devices(device_type=cl.device_type.GPU)
                elif device_type.lower() == 'cpu':
                    devices = platform.get_devices(device_type=cl.device_type.CPU)
                else:
                    devices = platform.get_devices()  # 所有設備
            except:
                continue
            
            for device in devices:
                logger.info(f"  📱 檢查設備: {device.name}")
                
                try:
                    # 使用改进的SVM检测器
                    svm_caps = EnhancedSVMCapabilityChecker.check_svm_support(
                        device, do_reality_check=do_reality_check
                    )
                    
                    device_info = {
                        'device': device,
                        'platform': platform,
                        'name': device.name,
                        'vendor': device.vendor,
                        'capabilities': svm_caps
                    }
                    
                    if svm_caps['has_svm']:
                        if do_reality_check:
                            if svm_caps['actually_usable']:
                                logger.info(f"    ✅ SVM實測可用")
                                
                                # 顯示性能信息
                                if 'performance_summary' in svm_caps:
                                    perf = svm_caps['performance_summary']
                                    if perf:
                                        largest_size = max(perf.keys())
                                        largest_perf = perf[largest_size]
                                        logger.info(f"       性能: {largest_perf['write_bandwidth']:.1f} MB/s")
                                
                                usable_devices.append(device_info)
                            else:
                                logger.warning(f"    ❌ SVM聲稱支持但實測失敗")
                                warnings = svm_caps.get('warnings', [])
                                for warning in warnings[:2]:  # 只顯示前2個警告
                                    logger.warning(f"       {warning}")
                        else:
                            logger.info(f"    ⚠️ SVM標記支持（未實測）")
                            usable_devices.append(device_info)
                    else:
                        logger.info(f"    ❌ 不支持SVM")
                
                except Exception as e:
                    logger.error(f"    ❌ 檢查過程異常: {e}")
    
    except Exception as e:
        logger.error(f"❌ 平台掃描異常: {e}")
    
    return usable_devices

def create_svm_manager(device_type: str = 'gpu', 
                     prefer_tested: bool = True) -> Optional[ImprovedSVMManager]:
    """创建SVM管理器的工厂函数（使用改进的库加载）"""
    try:
        # 检测可用设备
        usable_devices = detect_usable_svm_devices(device_type, do_reality_check=prefer_tested)
        
        if not usable_devices:
            logger.warning("❌ 未找到支持SVM的設備")
            return None
        
        # 选择最佳设备（可以添加更複雜的選擇邏輯）
        best_device_info = usable_devices[0]
        
        # 如果有多個設備，選擇性能最好的
        if len(usable_devices) > 1:
            logger.info(f"🎯 發現 {len(usable_devices)} 個可用設備，選擇最佳設備...")
            
            best_score = 0
            for device_info in usable_devices:
                score = 0
                caps = device_info['capabilities']
                
                # 基於各種因素計算分數
                if caps.get('actually_usable', False):
                    score += 100
                if caps.get('fine_grain_buffer', False):
                    score += 50
                if caps.get('atomics', False):
                    score += 25
                
                # 性能加分
                if 'performance_summary' in caps and caps['performance_summary']:
                    perf = caps['performance_summary']
                    largest_size = max(perf.keys())
                    bandwidth = perf[largest_size]['write_bandwidth']
                    score += min(bandwidth / 10, 50)  # 最多50分
                
                if score > best_score:
                    best_score = score
                    best_device_info = device_info
                    
            logger.info(f"✅ 選擇設備: {best_device_info['name']} (分數: {best_score})")
        
        device = best_device_info['device']
        context = cl.Context([device])
        queue = cl.CommandQueue(context)
        
        return ImprovedSVMManager(context, queue, skip_reality_check=not prefer_tested)
        
    except Exception as e:
        logger.error(f"❌ SVM管理器創建失敗: {e}")
        return None

def comprehensive_svm_test():
    """全面的SVM功能测试（使用改进的库加载机制）"""
    logger.info("🧪 開始全面SVM功能測試（使用改進的庫加載機制）...")
    
    # 设置调试模式
    os.environ['OPENCL_DEBUG'] = '1'
    
    # 首先检测所有可用设备
    logger.info("\n📋 第一階段：設備檢測")
    usable_devices = detect_usable_svm_devices('gpu', do_reality_check=True)
    
    if not usable_devices:
        logger.error("❌ 未找到可用的SVM設備")
        return False
    
    logger.info(f"\n✅ 找到 {len(usable_devices)} 個可用SVM設備")
    
    # 显示环境信息
    if usable_devices and 'capabilities' in usable_devices[0]:
        caps = usable_devices[0]['capabilities']
        if 'environment_info' in caps:
            env_info = caps['environment_info']
            logger.info(f"\n🔍 環境信息:")
            logger.info(f"   ICD可用: {env_info.get('icd_available', '未知')}")
            vendors = env_info.get('vendors_found', [])
            if vendors:
                logger.info(f"   檢測到廠商: {[v['name'] for v in vendors]}")
                
            if 'system_resources' in env_info:
                res = env_info['system_resources']
                logger.info(f"   系統資源: {res['total_memory_gb']:.1f}GB 記憶體, {res['cpu_count']} CPU核心")
    
    # 创建管理器进行详细测试
    logger.info("\n📋 第二階段：功能測試")
    manager = create_svm_manager('gpu', prefer_tested=True)
    if not manager:
        logger.error("❌ 無法創建SVM管理器")
        return False
    
    try:
        # 簡單測試
        logger.info(f"\n🔍 基本分配測試...")
        
        test_sizes = [1024, 4096, 16384, 65536]  # 不同大小測試
        
        for size in test_sizes:
            data = np.random.rand(size // 4).astype(np.float32)  # 4 bytes per float32
            
            # 分配SVM内存
            start_time = time.time()
            ptr = manager.allocate(data.nbytes, name=f"test_buffer_{size}")
            alloc_time = (time.time() - start_time) * 1000
            
            logger.info(f"✅ 成功分配 {size} 字節SVM記憶體 ({alloc_time:.2f}ms)")
            
            # 释放内存
            start_time = time.time()
            manager.free(ptr, f"test_buffer_{size}")
            free_time = (time.time() - start_time) * 1000
            
            logger.info(f"✅ 成功釋放SVM記憶體 ({free_time:.2f}ms)")
        
        # 壓力測試
        logger.info(f"\n🔍 壓力分配測試...")
        allocated_ptrs = []
        
        try:
            for i in range(20):  # 嘗試分配20個緩衝區
                ptr = manager.allocate(1024*1024, name=f"stress_buffer_{i}")  # 1MB each
                allocated_ptrs.append((ptr, f"stress_buffer_{i}"))
                
            logger.info(f"✅ 壓力測試：成功分配 {len(allocated_ptrs)} 個1MB緩衝區")
            
        finally:
            # 清理所有壓力測試緩衝區
            for ptr, name in allocated_ptrs:
                manager.free(ptr, name)
        
        # 显示设备信息和統計
        device_info = manager.get_device_info()
        logger.info(f"\n📊 設備信息:")
        logger.info(f"   設備: {device_info['device_name']}")
        logger.info(f"   廠商: {device_info['device_vendor']}")
        logger.info(f"   驅動版本: {device_info['driver_version']}")
        
        if 'environment_info' in device_info:
            env_info = device_info['environment_info']
            logger.info(f"   庫加載方式: {'ICD' if env_info.get('icd_available') else '直接加載'}")
        
        # 顯示性能統計
        if 'performance_summary' in device_info:
            perf = device_info['performance_summary']
            logger.info(f"   平均分配時間: {perf['avg_allocation_time_ms']:.2f} ms")
            logger.info(f"   最大分配時間: {perf['max_allocation_time_ms']:.2f} ms")
            
        # 顯示分配統計
        alloc_stats = manager.get_allocation_stats()
        logger.info(f"   分配成功率: {alloc_stats['success_rate']:.1%}")
        logger.info(f"   峰值記憶體: {alloc_stats['peak_allocated_bytes'] / 1024 / 1024:.1f} MB")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ 測試過程異常: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        manager.cleanup()

if __name__ == "__main__":
    # 支持命令行參數
    import sys
    
    if "--debug" in sys.argv:
        logging.getLogger().setLevel(logging.DEBUG)
        os.environ['OPENCL_DEBUG'] = '1'
    
    success = comprehensive_svm_test()
    if success:
        logger.info("\n🎉 所有SVM測試通過（使用改進的庫加載機制）!")
    else:
        logger.error("\n💥 部分SVM測試失敗!")
        sys.exit(1)