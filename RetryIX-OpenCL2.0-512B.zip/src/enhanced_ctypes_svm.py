#!/usr/bin/env python3
"""
Improved OpenCL SVM Manager - Fully optimized version
Fixes library loading mechanism to avoid DLL search priority issues
Follows standard ICD mechanism for better stability and portability
Integrates monitoring and performance optimization features
"""

import os
import ctypes
from ctypes import c_void_p, c_size_t, c_uint, c_int, c_ulong, POINTER
import platform
import numpy as np
import pyopencl as cl
import time
import subprocess
import sys
from typing import Optional, Dict, Any, List, Union, Tuple
import warnings
import winreg
from pathlib import Path
import logging
from collections import defaultdict, deque
import psutil

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# OpenCL constants
CL_SUCCESS = 0
CL_MEM_READ_WRITE = 1 << 0
CL_MEM_SVM_FINE_GRAIN_BUFFER = 1 << 10
CL_MAP_READ = 1 << 0
CL_MAP_WRITE = 1 << 1

class OpenCLEnvironmentManager:
    """OpenCL environment manager - responsible for proper library discovery and loading"""
    
    def __init__(self):
        self.system = platform.system()
        self.arch = platform.architecture()[0]
        self.debug_mode = os.getenv('OPENCL_DEBUG', '0') == '1'
        
    def setup_opencl_environment(self) -> Dict[str, Any]:
        """Set up OpenCL environment, prefer ICD mechanism"""
        env_info = {
            'icd_available': False,
            'vendors_found': [],
            'library_path': None,
            'warnings': [],
            'environment_vars': {},
            'system_info': {
                'platform': self.system,
                'architecture': self.arch,
                'python_version': sys.version,
                'pyopencl_version': cl.version.VERSION_TEXT if hasattr(cl.version, 'VERSION_TEXT') else 'unknown'
            }
        }
        
        # 1. Check and set environment variables
        self._setup_environment_variables(env_info)
        # 2. Validate ICD mechanism
        self._check_icd_mechanism(env_info)
        # 3. Discover available vendors
        self._discover_opencl_vendors(env_info)
        # 4. System resource check
        self._check_system_resources(env_info)
        if self.debug_mode:
            self._print_environment_info(env_info)
        return env_info
    
    def _setup_environment_variables(self, env_info: Dict):
        """Set OpenCL related environment variables"""
        # Check user custom path
        custom_path = os.getenv('OPENCL_VENDOR_PATH')
        if custom_path:
            env_info['environment_vars']['OPENCL_VENDOR_PATH'] = custom_path
        # Check PyOpenCL specific setting
        pyocl_ctx = os.getenv('PYOPENCL_CTX')
        if pyocl_ctx:
            env_info['environment_vars']['PYOPENCL_CTX'] = pyocl_ctx
        # Windows specific: check and set DLL search path
        if self.system == "Windows":
            self._setup_windows_dll_path(env_info)
    
    def _setup_windows_dll_path(self, env_info: Dict):
        """Windows only: safely set DLL search path"""
        try:
            # Check if local bin directory exists
            bin_path = Path("bin").resolve()
            if bin_path.exists():
                # Use Python 3.8+ safe DLL directory mechanism
                if hasattr(os, 'add_dll_directory'):
                    os.add_dll_directory(str(bin_path))
                    env_info['warnings'].append(
                        f"Added local DLL directory: {bin_path} (for development/testing only)"
                    )
                else:
                    # For older Python, modify PATH but warn
                    original_path = os.environ.get('PATH', '')
                    os.environ['PATH'] = f"{bin_path};{original_path}"
                    env_info['warnings'].append(
                        "Warning: Used PATH modification to load local DLL, upgrade to Python 3.8+ recommended"
                    )
        except Exception as e:
            env_info['warnings'].append(f"Error setting Windows DLL path: {e}")
    
    def _check_icd_mechanism(self, env_info: Dict):
        """Check if OpenCL ICD mechanism is working"""
        try:
            if self.system == "Windows":
                self._check_windows_icd(env_info)
            elif self.system == "Linux":
                self._check_linux_icd(env_info)
            elif self.system == "Darwin":
                self._check_macos_icd(env_info)
                
        except Exception as e:
            env_info['warnings'].append(f"Error checking ICD mechanism: {e}")
    
    def _check_windows_icd(self, env_info: Dict):
        """Check Windows OpenCL ICD registry"""
        try:
            # Check 64-bit registry
            reg_paths = [
                r"SOFTWARE\Khronos\OpenCL\Vendors",
                r"SOFTWARE\WOW6432Node\Khronos\OpenCL\Vendors",
                r"SOFTWARE\RetryIX\Core"
            ]
            vendors_found = []
            for reg_path in reg_paths:
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path) as key:
                        i = 0
                        while True:
                            try:
                                vendor_dll, _ = winreg.EnumValue(key, i)
                                if os.path.exists(vendor_dll):
                                    vendor_name = self._identify_vendor_from_path(vendor_dll)
                                    vendors_found.append({
                                        'name': vendor_name,
                                        'dll_path': vendor_dll,
                                        'registry_path': reg_path,
                                        'file_size': os.path.getsize(vendor_dll),
                                        'modified_time': os.path.getmtime(vendor_dll)
                                    })
                                i += 1
                            except WindowsError:
                                break
                except FileNotFoundError:
                    continue
            if vendors_found:
                env_info['icd_available'] = True
                env_info['vendors_found'] = vendors_found
                logger.debug(f"Windows ICD detected {len(vendors_found)} vendors")
            else:
                env_info['warnings'].append("No OpenCL vendors found in Windows registry")
        except Exception as e:
            env_info['warnings'].append(f"Failed to check Windows ICD: {e}")
    
    def _check_linux_icd(self, env_info: Dict):
        """Check Linux OpenCL ICD configuration"""
        icd_paths = [
            "/etc/OpenCL/vendors",
            "/usr/share/OpenCL/vendors",
            "/usr/local/share/OpenCL/vendors",
            "/opt/intel/opencl/vendors"  # Intel specific path
        ]
        vendors_found = []
        for icd_path in icd_paths:
            if os.path.exists(icd_path):
                for icd_file in os.listdir(icd_path):
                    if icd_file.endswith('.icd'):
                        icd_full_path = os.path.join(icd_path, icd_file)
                        try:
                            with open(icd_full_path, 'r') as f:
                                vendor_lib = f.read().strip()
                                if os.path.exists(vendor_lib):
                                    vendor_name = self._identify_vendor_from_path(vendor_lib)
                                    vendors_found.append({
                                        'name': vendor_name,
                                        'lib_path': vendor_lib,
                                        'icd_file': icd_full_path,
                                        'file_size': os.path.getsize(vendor_lib),
                                        'modified_time': os.path.getmtime(vendor_lib)
                                    })
                        except Exception:
                            continue
        if vendors_found:
            env_info['icd_available'] = True
            env_info['vendors_found'] = vendors_found
            logger.debug(f"Linux ICD detected {len(vendors_found)} vendors")
        else:
            env_info['warnings'].append("No valid vendors found in Linux ICD directories")
    
    def _check_macos_icd(self, env_info: Dict):
        """Check macOS OpenCL framework"""
        framework_path = "/System/Library/Frameworks/OpenCL.framework/OpenCL"
        if os.path.exists(framework_path):
            env_info['icd_available'] = True
            env_info['vendors_found'] = [{
                'name': 'Apple',
                'framework_path': framework_path,
                'file_size': os.path.getsize(framework_path),
                'modified_time': os.path.getmtime(framework_path)
            }]
            logger.debug("macOS OpenCL framework detected")
        else:
            env_info['warnings'].append("macOS OpenCL framework not found")
    
    def _check_system_resources(self, env_info: Dict):
        """Check system resources"""
        try:
            memory = psutil.virtual_memory()
            env_info['system_resources'] = {
                'total_memory_gb': memory.total / (1024**3),
                'available_memory_gb': memory.available / (1024**3),
                'cpu_count': psutil.cpu_count(),
                'cpu_freq_mhz': psutil.cpu_freq().current if psutil.cpu_freq() else 0
            }
        except Exception as e:
            env_info['warnings'].append(f"System resource check failed: {e}")
    
    def _identify_vendor_from_path(self, path: str) -> str:
        """Identify vendor from path"""
        path_lower = path.lower()
        if 'amd' in path_lower or 'ati' in path_lower:
            return 'AMD'
        elif 'nvidia' in path_lower or 'nvopencl' in path_lower:
            return 'NVIDIA'  
        elif 'intel' in path_lower:
            return 'Intel'
        elif 'apple' in path_lower:
            return 'Apple'
        elif 'mesa' in path_lower:
            return 'Mesa'
        else:
            return 'Unknown'
    
    def _discover_opencl_vendors(self, env_info: Dict):
        """Discover available OpenCL vendors (supplement ICD mechanism)"""
        if env_info['icd_available']:
            return  # ICD works, no need for extra discovery
        fallback_paths = self._get_fallback_library_paths()
        for lib_path in fallback_paths:
            try:
                if self.system == "Windows":
                    lib = ctypes.windll.LoadLibrary(lib_path)
                    vendor_name = self._identify_vendor_from_path(lib_path)
                    env_info['vendors_found'].append({
                        'name': vendor_name,
                        'lib_path': lib_path,
                        'fallback': True
                    })
                else:
                    lib = ctypes.CDLL(lib_path)
                    vendor_name = self._identify_vendor_from_path(lib_path)
                    env_info['vendors_found'].append({
                        'name': vendor_name,
                        'lib_path': lib_path,
                        'fallback': True
                    })
            except OSError:
                continue
    
    def _get_fallback_library_paths(self) -> List[str]:
        """Get fallback library paths"""
        if self.system == "Windows":
            return [
                "retryix.dll"  # System standard ICD loader
            ]
        elif self.system == "Linux":
            return [
                "libOpenCL.so.1",
                "libOpenCL.so",
                "/usr/lib/x86_64-linux-gnu/libOpenCL.so.1",
                "/usr/lib64/libOpenCL.so.1",
                "/usr/local/lib/libOpenCL.so.1"
            ]
        elif self.system == "Darwin":
            return ["/System/Library/Frameworks/OpenCL.framework/OpenCL"]
        else:
            return []
    
    def _print_environment_info(self, env_info: Dict):
        """Print environment info (debug mode)"""
        logger.info("OpenCL environment details:")
        logger.info(f"   System: {self.system} ({self.arch})")
        logger.info(f"   ICD available: {env_info['icd_available']}")
        logger.info(f"   Vendors found: {len(env_info['vendors_found'])}")
        for vendor in env_info['vendors_found']:
            logger.info(f"     - {vendor['name']}: {vendor}")
        if 'system_resources' in env_info:
            res = env_info['system_resources']
            logger.info(f"   System resources:")
            logger.info(f"     Total memory: {res['total_memory_gb']:.1f} GB")
            logger.info(f"     Available memory: {res['available_memory_gb']:.1f} GB")
            logger.info(f"     CPU cores: {res['cpu_count']}")
        if env_info['warnings']:
            logger.warning("   Warnings:")
            for warning in env_info['warnings']:
                logger.warning(f"     {warning}")

class ImprovedOpenCLLibraryLoader:
    """Improved OpenCL library loader - follows ICD standard"""
    
    def __init__(self):
        self.lib = None
        self.env_manager = OpenCLEnvironmentManager()
        self.env_info = None
        self._load_opencl_library()
    
    def _load_opencl_library(self):
        """Intelligent OpenCL library loading"""
        # Setup environment
        self.env_info = self.env_manager.setup_opencl_environment()
        
        # Strategy 1: Prefer system ICD loader
        if self._try_load_system_icd():
            return
            
        # Strategy 2: Direct PyOpenCL detection
        if self._try_pyopencl_detection():
            return
            
        # Strategy 3: Fallback direct loading
        if self._try_fallback_loading():
            return
            
        # All strategies failed
        self._handle_loading_failure()
    
    def _try_load_system_icd(self) -> bool:
        """Try loading system ICD loader"""
        try:
            if self.env_manager.system == "Windows":
                # Windows prefer system OpenCL.dll (ICD loader)
                self.lib = ctypes.windll.OpenCL
                logger.info("Using Windows ICD loader")
                self.env_info['icd_available'] = True  # Fix display logic
                return True
            elif self.env_manager.system == "Linux":
                # Linux use standard libOpenCL.so
                self.lib = ctypes.CDLL("libOpenCL.so.1")
                logger.info("Using Linux system ICD loader")
                self.env_info['icd_available'] = True
                return True
            elif self.env_manager.system == "Darwin":
                # macOS use framework
                framework_path = "/System/Library/Frameworks/OpenCL.framework/OpenCL"
                self.lib = ctypes.CDLL(framework_path)
                logger.info("Using macOS OpenCL framework")
                self.env_info['icd_available'] = True
                return True
        except OSError as e:
            if self.env_manager.debug_mode:
                logger.debug(f"System ICD loading failed: {e}")
            return False
        
        return False
    
    def _try_pyopencl_detection(self) -> bool:
        """Detect OpenCL availability through PyOpenCL"""
        try:
            # Let PyOpenCL detect and load itself
            platforms = cl.get_platforms()
            if platforms:
                # PyOpenCL succeeded, try to get the library it uses
                self.lib = self._extract_lib_from_pyopencl()
                if self.lib:
                    logger.info("OpenCL library detected through PyOpenCL")
                    return True
        except Exception as e:
            if self.env_manager.debug_mode:
                logger.debug(f"PyOpenCL detection failed: {e}")
            return False
        
        return False
    
    def _extract_lib_from_pyopencl(self):
        """Extract underlying library reference from PyOpenCL"""
        try:
            # This is an advanced technique, try to get underlying library from PyOpenCL
            if hasattr(cl, '_lib'):
                return cl._lib
            
            # Fallback method: get through platform object
            platform = cl.get_platforms()[0]
            if hasattr(platform, '_lib'):
                return platform._lib
                
            # If can't get directly, use standard loading method
            if self.env_manager.system == "Windows":
                return ctypes.windll.OpenCL
            else:
                return ctypes.CDLL("libOpenCL.so.1")
                
        except Exception:
            return None
    
    def _try_fallback_loading(self) -> bool:
        """Fallback loading method"""
        if not self.env_info['vendors_found']:
            return False
        
        # Try loading found vendor libraries
        for vendor in self.env_info['vendors_found']:
            try:
                if 'dll_path' in vendor:
                    lib_path = vendor['dll_path']
                elif 'lib_path' in vendor:
                    lib_path = vendor['lib_path']
                elif 'framework_path' in vendor:
                    lib_path = vendor['framework_path']
                else:
                    continue
                
                if self.env_manager.system == "Windows":
                    self.lib = ctypes.windll.LoadLibrary(lib_path)
                else:
                    self.lib = ctypes.CDLL(lib_path)
                
                fallback_marker = " (fallback)" if vendor.get('fallback') else ""
                logger.info(f"Loaded {vendor['name']} vendor library{fallback_marker}: {lib_path}")
                return True
                
            except OSError as e:
                logger.debug(f"Failed to load {vendor['name']}: {e}")
                continue
        
        return False
    
    def _handle_loading_failure(self):
        """Handle loading failure"""
        error_msg = "Unable to load OpenCL library."
        
        if not self.env_info['vendors_found']:
            error_msg += "\nNo OpenCL vendors detected. Please install graphics driver or OpenCL runtime."
        else:
            error_msg += f"\nDetected {len(self.env_info['vendors_found'])} vendors but loading failed:"
            for vendor in self.env_info['vendors_found']:
                error_msg += f"\n  - {vendor['name']}"
        
        if self.env_info['warnings']:
            error_msg += "\nWarning messages:"
            for warning in self.env_info['warnings']:
                error_msg += f"\n  {warning}"
        
        error_msg += "\n\nSolution recommendations:"
        error_msg += "\n1. Check if graphics driver is properly installed"
        error_msg += "\n2. Install OpenCL runtime (Intel/AMD/NVIDIA)"
        error_msg += "\n3. Set environment variable OPENCL_DEBUG=1 for detailed info"
        error_msg += "\n4. Check system architecture (32-bit vs 64-bit) matching"
        
        raise RuntimeError(error_msg)
    
    def get_environment_info(self) -> Dict[str, Any]:
        """Get environment information"""
        return self.env_info

class SVMRealityChecker:
    """SVM reality availability checker - enhanced version"""
    
    def __init__(self, lib_loader: ImprovedOpenCLLibraryLoader):
        self.lib = lib_loader.lib
        self.env_info = lib_loader.get_environment_info()
        self._setup_function_prototypes()
        
        # Known problematic drivers/platforms
        self.problematic_vendors = {
            'apple': "macOS OpenCL SVM support is unstable",
            'nvidia': "Old NVIDIA drivers have problematic SVM support", 
            'intel': "Some Intel iGPU SVM implementations are incomplete",
            'mesa': "Mesa open source driver SVM support is limited"
        }
        # Performance benchmark sizes
        self.benchmark_sizes = [1024, 4096, 16384, 65536]  # Different test sizes
        self.performance_results = {}
    
    def _setup_function_prototypes(self):
        """Set OpenCL function prototypes"""
        # clSVMAlloc
        self.lib.clSVMAlloc.argtypes = [
            c_void_p,    # context
            c_ulong,     # flags
            c_size_t,    # size
            c_uint       # alignment
        ]
        self.lib.clSVMAlloc.restype = c_void_p
        
        # clSVMFree
        self.lib.clSVMFree.argtypes = [
            c_void_p,    # context
            c_void_p     # svm_pointer
        ]
        self.lib.clSVMFree.restype = None
        
        # clEnqueueSVMMap
        self.lib.clEnqueueSVMMap.argtypes = [
            c_void_p, c_uint, c_ulong, c_void_p, c_size_t,
            c_uint, POINTER(c_void_p), POINTER(c_void_p)
        ]
        self.lib.clEnqueueSVMMap.restype = c_int
        
        # clEnqueueSVMUnmap
        self.lib.clEnqueueSVMUnmap.argtypes = [
            c_void_p, c_void_p, c_uint, POINTER(c_void_p), POINTER(c_void_p)
        ]
        self.lib.clEnqueueSVMUnmap.restype = c_int
    
    def check_vendor_compatibility(self, device: cl.Device) -> Tuple[bool, str]:
        """Check vendor compatibility - combined with environment info"""
        vendor = device.vendor.lower()
        detected_vendors = [v['name'].lower() for v in self.env_info.get('vendors_found', [])]
        for problematic, reason in self.problematic_vendors.items():
            if problematic in vendor:
                if problematic in detected_vendors:
                    driver_version = getattr(device, 'driver_version', '')
                    if self._is_known_good_version(vendor, driver_version):
                        return True, f"Known good version: {driver_version}"
                    else:
                        return False, f"{reason} (environment detected: {driver_version})"
                else:
                    return False, f"{reason} (vendor not detected in environment)"
        return True, "Vendor compatibility check passed"
    
    def _is_known_good_version(self, vendor: str, driver_version: str) -> bool:
        """Check if version is known good"""
        known_good = {
            'nvidia': ['470.', '480.', '490.', '510.', '520.', '530.', '540.'],
            'amd': ['21.', '22.', '23.', '24.', '25.'],
            'intel': ['27.', '28.', '29.', '30.', '31.', '32.'],
            'apple': ['14.', '15.']  # macOS versions
        }
        for vendor_key in known_good:
            if vendor_key in vendor:
                return any(driver_version.startswith(good_ver) 
                          for good_ver in known_good[vendor_key])
        return False
    
    def test_basic_allocation(self, context: cl.Context) -> Tuple[bool, str]:
        """Test basic SVM allocation and free"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            size = 1024  # 1KB test
            alignment = 64
            
            # Try allocation
            svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            if not svm_ptr:
                return False, "clSVMAlloc returned null pointer"
            # Immediately free
            self.lib.clSVMFree(ctx_ptr, svm_ptr)
            return True, "Basic allocation test passed"
        except Exception as e:
            return False, f"Basic allocation test exception: {e}"
    
    def test_memory_access(self, context: cl.Context) -> Tuple[bool, str]:
        """Test SVM memory read/write access"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            size = 256
            alignment = 64
            
            # Allocate SVM memory
            svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            if not svm_ptr:
                return False, "Allocation failed"
            try:
                # Create ctypes array for read/write test
                test_data = (ctypes.c_uint8 * size).from_address(svm_ptr)
                # Write test pattern
                test_pattern = [i % 256 for i in range(size)]
                for i, val in enumerate(test_pattern):
                    test_data[i] = val
                # Read back and verify
                for i, expected in enumerate(test_pattern):
                    if test_data[i] != expected:
                        return False, f"Data mismatch at {i}: expected {expected}, got {test_data[i]}"
                return True, "Memory access test passed"
            finally:
                self.lib.clSVMFree(ctx_ptr, svm_ptr)
        except Exception as e:
            return False, f"Memory access test exception: {e}"
    
    def test_performance_benchmark(self, context: cl.Context) -> Tuple[bool, str]:
        """Performance benchmark test"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            alignment = 64
            
            performance_data = {}
            
            for size in self.benchmark_sizes:
                # Allocation test
                start_time = time.time()
                svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
                alloc_time = time.time() - start_time
                if not svm_ptr:
                    continue
                try:
                    # Write test
                    test_data = (ctypes.c_uint8 * size).from_address(svm_ptr)
                    start_time = time.time()
                    for i in range(size):
                        test_data[i] = i % 256
                    write_time = time.time() - start_time
                    # Read test
                    start_time = time.time()
                    checksum = sum(test_data[i] for i in range(0, size, 64))  # Sample check
                    read_time = time.time() - start_time
                    performance_data[size] = {
                        'alloc_time': alloc_time * 1000,  # ms
                        'write_time': write_time * 1000,
                        'read_time': read_time * 1000,
                        'write_bandwidth': size / write_time / 1024 / 1024,  # MB/s
                        'read_bandwidth': (size / 64) / read_time / 1024 / 1024  # Sample bandwidth
                    }
                finally:
                    self.lib.clSVMFree(ctx_ptr, svm_ptr)
            self.performance_results = performance_data
            if performance_data:
                avg_write_bw = sum(d['write_bandwidth'] for d in performance_data.values()) / len(performance_data)
                return True, f"Performance test passed, average write bandwidth: {avg_write_bw:.1f} MB/s"
            else:
                return False, "Performance test: allocation failed for all sizes"
        except Exception as e:
            return False, f"Performance test exception: {e}"
    
    def test_stress_allocation(self, context: cl.Context) -> Tuple[bool, str]:
        """Stress allocation test"""
        try:
            ctx_ptr = c_void_p(int(context.int_ptr))
            flags = CL_MEM_READ_WRITE
            alignment = 64
            
            # Try allocating multiple buffers of different sizes
            allocated_ptrs = []
            total_allocated = 0
            # Allocation strategy: small to large, test fragmentation
            test_sizes = [1024, 4096, 16384, 65536, 262144]  # 1KB to 256KB
            for size in test_sizes:
                for i in range(5):  # 5 per size
                    svm_ptr = self.lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
                    if svm_ptr:
                        allocated_ptrs.append(svm_ptr)
                        total_allocated += size
                    else:
                        break
            if not allocated_ptrs:
                return False, "Stress test: could not allocate any buffer"
            # Free all buffers
            for ptr in allocated_ptrs:
                self.lib.clSVMFree(ctx_ptr, ptr)
            return True, f"Stress test passed: allocated {len(allocated_ptrs)} buffers, total {total_allocated/1024:.1f} KB"
        except Exception as e:
            return False, f"Stress test exception: {e}"
    
    def run_comprehensive_test(self, context: cl.Context, queue: cl.CommandQueue) -> Dict[str, Any]:
        """Run comprehensive SVM usability test (enhanced version)"""
        results = {
            'vendor_check': False,
            'basic_allocation': False,
            'memory_access': False,
            'performance_benchmark': False,
            'stress_allocation': False,
            'environment_info': self.env_info,
            'overall_usable': False,
            'performance_data': {},
            'messages': [],
            'recommendations': []
        }
        device = queue.device
        # 1. Vendor compatibility check
        vendor_ok, vendor_msg = self.check_vendor_compatibility(device)
        results['vendor_check'] = vendor_ok
        results['messages'].append(f"Vendor check: {vendor_msg}")
        if not vendor_ok:
            results['messages'].append("Vendor compatibility issue, continuing test...")
            results['recommendations'].append("Consider updating GPU driver to latest version")
        # 2. Basic allocation test
        alloc_ok, alloc_msg = self.test_basic_allocation(context)
        results['basic_allocation'] = alloc_ok
        results['messages'].append(f"Basic allocation: {alloc_msg}")
        if not alloc_ok:
            results['messages'].append("Basic allocation failed, stopping further tests")
            results['recommendations'].append("Check if OpenCL driver is properly installed")
            return results
        # 3. Memory access test
        access_ok, access_msg = self.test_memory_access(context)
        results['memory_access'] = access_ok
        results['messages'].append(f"Memory access: {access_msg}")
        if not access_ok:
            results['recommendations'].append("Memory access issue, possibly hardware related")
        # 4. Performance benchmark
        perf_ok, perf_msg = self.test_performance_benchmark(context)
        results['performance_benchmark'] = perf_ok
        results['messages'].append(f"Performance test: {perf_msg}")
        results['performance_data'] = self.performance_results
        if perf_ok:
            if self.performance_results:
                largest_size = max(self.performance_results.keys())
                largest_perf = self.performance_results[largest_size]
                if largest_perf['write_bandwidth'] < 100:  # MB/s
                    results['recommendations'].append("SVM write performance is low, consider using smaller buffers")
        # 5. Stress allocation test
        stress_ok, stress_msg = self.test_stress_allocation(context)
        results['stress_allocation'] = stress_ok
        results['messages'].append(f"Stress test: {stress_msg}")
        if not stress_ok:
            results['recommendations'].append("Stress test failed, avoid allocating too many buffers at once")
        # Overall evaluation
        critical_tests = [alloc_ok, access_ok]
        important_tests = [perf_ok, stress_ok]
        results['overall_usable'] = all(critical_tests) and any(important_tests)
        if results['overall_usable']:
            results['messages'].append("SVM comprehensive test passed, actually usable")
            if vendor_ok and perf_ok and stress_ok:
                results['recommendations'].append("SVM performance is good, recommended for HPC")
            elif not stress_ok:
                results['recommendations'].append("Avoid over-allocation, consider using memory pool")
        else:
            failed_tests = []
            if not alloc_ok: failed_tests.append("allocation")
            if not access_ok: failed_tests.append("access")
            if not perf_ok: failed_tests.append("performance")
            if not stress_ok: failed_tests.append("stress")
            results['messages'].append(f"SVM not usable, failed tests: {', '.join(failed_tests)}")
            results['recommendations'].append("Consider using traditional OpenCL buffers instead of SVM")
        return results

class EnhancedSVMCapabilityChecker:
    """Enhanced SVM capability checker - integrated improved library loading"""
    
    @staticmethod
    def check_svm_support(device: cl.Device, do_reality_check: bool = True) -> Dict[str, Any]:
        """Check device SVM support capabilities (using improved library loading)"""
        capabilities = {
            'has_svm': False,
            'coarse_grain_buffer': False,
            'fine_grain_buffer': False,
            'fine_grain_system': False,
            'atomics': False,
            'reality_tested': False,
            'actually_usable': False,
            'test_results': {},
            'warnings': [],
            'device_info': {
                'name': device.name,
                'vendor': device.vendor,
                'version': device.opencl_c_version,
                'driver_version': getattr(device, 'driver_version', 'unknown'),
                'max_memory': device.max_mem_alloc_size,
                'global_memory': device.global_mem_size
            }
        }
        
        try:
            # Check basic SVM support
            svm_caps = device.svm_capabilities
            
            if svm_caps:
                capabilities['has_svm'] = True
                
                # Check specific capabilities
                if svm_caps & cl.device_svm_capabilities.COARSE_GRAIN_BUFFER:
                    capabilities['coarse_grain_buffer'] = True
                
                if svm_caps & cl.device_svm_capabilities.FINE_GRAIN_BUFFER:
                    capabilities['fine_grain_buffer'] = True
                
                if svm_caps & cl.device_svm_capabilities.FINE_GRAIN_SYSTEM:
                    capabilities['fine_grain_system'] = True
                
                if svm_caps & cl.device_svm_capabilities.ATOMICS:
                    capabilities['atomics'] = True
        
        except (AttributeError, cl.LogicError):
            capabilities['warnings'].append("Device does not report SVM capabilities")
        
        # Perform low-level reality test (using improved library loader)
        if do_reality_check and capabilities['has_svm']:
            try:
                context = cl.Context([device])
                queue = cl.CommandQueue(context)
                
                # Use improved library loader
                lib_loader = ImprovedOpenCLLibraryLoader()
                reality_checker = SVMRealityChecker(lib_loader)
                
                test_results = reality_checker.run_comprehensive_test(context, queue)
                
                capabilities['reality_tested'] = True
                capabilities['actually_usable'] = test_results['overall_usable']
                capabilities['test_results'] = test_results
                
                # Collect environment info
                capabilities['environment_info'] = test_results['environment_info']
                
                # Collect warning info
                if not test_results['vendor_check']:
                    capabilities['warnings'].append("Vendor compatibility issue")
                
                if capabilities['has_svm'] and not capabilities['actually_usable']:
                    capabilities['warnings'].append("Claims SVM support but reality test failed")
                
                # Add performance recommendations
                if 'performance_data' in test_results and test_results['performance_data']:
                    capabilities['performance_summary'] = test_results['performance_data']
                
                if 'recommendations' in test_results:
                    capabilities['recommendations'] = test_results['recommendations']
                
            except Exception as e:
                capabilities['warnings'].append(f"Reality test exception: {e}")
                capabilities['reality_tested'] = False
        
        return capabilities

class ImprovedSVMManager:
    """Improved SVM manager - using new library loading mechanism and performance monitoring"""
    
    def __init__(self, context: cl.Context, queue: cl.CommandQueue, 
                 skip_reality_check: bool = False):
        self.context = context
        self.queue = queue
        self.device = queue.device
        
        # Check SVM support (using improved checker)
        self.svm_capabilities = EnhancedSVMCapabilityChecker.check_svm_support(
            self.device, do_reality_check=not skip_reality_check
        )
        
        # Strict validation
        if not self.svm_capabilities['has_svm']:
            raise RuntimeError(f"Device {self.device.name} does not support SVM")
        
        if not skip_reality_check:
            if not self.svm_capabilities['actually_usable']:
                warnings_msg = "; ".join(self.svm_capabilities['warnings'])
                raise RuntimeError(
                    f"Device {self.device.name} claims SVM support, but low-level reality test failed. "
                    f"Reason: {warnings_msg}"
                )
        
        # Use improved library loader
        try:
            self.lib_loader = ImprovedOpenCLLibraryLoader()
            self._lib = self.lib_loader.lib
            self._setup_function_prototypes()
        except RuntimeError as e:
            raise RuntimeError(f"SVM initialization failed: {e}")
        
        # SVM buffer management
        self.svm_buffers = {}
        self.next_buffer_id = 0
        
        # Performance monitoring
        self.allocation_stats = {
            'total_allocations': 0,
            'total_deallocations': 0,
            'current_allocated_bytes': 0,
            'peak_allocated_bytes': 0,
            'allocation_times': deque(maxlen=100),
            'deallocation_times': deque(maxlen=100),
            'failed_allocations': 0
        }
        
        # Print initialization info
        logger.info(f"SVM Manager initialization succeeded")
        logger.info(f"   Device: {self.device.name}")
        
        # Show environment info
        if 'environment_info' in self.svm_capabilities:
            env_info = self.svm_capabilities['environment_info']
            if env_info and env_info.get('vendors_found'):
                logger.info(f"   Vendor detected: {[v['name'] for v in env_info['vendors_found']]}")
                logger.info(f"   Use ICD: {'Yes' if env_info.get('icd_available', False) else 'No'}")

        if self.svm_capabilities['reality_tested']:
            result = 'Available' if self.svm_capabilities['actually_usable'] else 'Not Available'
            logger.info(f"   Reality test result: {result}")
            
        # Show performance info
        if 'performance_summary' in self.svm_capabilities:
            perf = self.svm_capabilities['performance_summary']
            if perf:
                largest_size = max(perf.keys())
                largest_perf = perf[largest_size]
                logger.info(f"   Performance benchmark: {largest_perf['write_bandwidth']:.1f} MB/s write bandwidth")
        
        # Show recommendations
        if 'recommendations' in self.svm_capabilities:
            for rec in self.svm_capabilities['recommendations'][:2]:  # Show only first 2
                logger.info(f"   Recommendation: {rec}")
    
    def _setup_function_prototypes(self):
        """Set OpenCL function prototypes"""
        # clSVMAlloc
        self._lib.clSVMAlloc.argtypes = [
            c_void_p,    # context
            c_ulong,     # flags
            c_size_t,    # size
            c_uint       # alignment
        ]
        self._lib.clSVMAlloc.restype = c_void_p
        
        # clSVMFree
        self._lib.clSVMFree.argtypes = [
            c_void_p,    # context
            c_void_p     # svm_pointer
        ]
        self._lib.clSVMFree.restype = None
    
    def allocate(self, size: int, alignment: int = 64, 
                flags: Optional[int] = None, name: Optional[str] = None) -> int:
        """Allocate SVM memory - enhanced monitoring"""
        
        start_time = time.time()
        
        if flags is None:
            # Choose best flags based on device capabilities
            if self.svm_capabilities['fine_grain_buffer']:
                flags = CL_MEM_READ_WRITE | CL_MEM_SVM_FINE_GRAIN_BUFFER
            else:
                flags = CL_MEM_READ_WRITE
        
        try:
            ctx_ptr = c_void_p(int(self.context.int_ptr))
            svm_ptr = self._lib.clSVMAlloc(ctx_ptr, flags, size, alignment)
            
            allocation_time = time.time() - start_time
            
            if not svm_ptr:
                self.allocation_stats['failed_allocations'] += 1
                raise RuntimeError(f"SVM allocation failed (size={size}, flags={flags})")
            
            # Record buffer
            buffer_id = name or f"buffer_{self.next_buffer_id}"
            self.next_buffer_id += 1
            
            self.svm_buffers[buffer_id] = {
                'ptr': svm_ptr,
                'size': size,
                'flags': flags,
                'alignment': alignment,
                'created_at': time.time(),
                'allocation_time': allocation_time
            }
            
            # Update statistics
            self.allocation_stats['total_allocations'] += 1
            self.allocation_stats['current_allocated_bytes'] += size
            self.allocation_stats['peak_allocated_bytes'] = max(
                self.allocation_stats['peak_allocated_bytes'],
                self.allocation_stats['current_allocated_bytes']
            )
            self.allocation_stats['allocation_times'].append(allocation_time * 1000)  # milliseconds
            
            logger.debug(f"SVM allocation successful: {buffer_id} ({size} bytes, {allocation_time*1000:.2f}ms)")
            
            return svm_ptr
            
        except Exception as e:
            self.allocation_stats['failed_allocations'] += 1
            logger.error(f"SVM allocation failed: {e}")
            raise
    
    def free(self, svm_ptr: int, name: Optional[str] = None):
        """Free SVM memory - enhanced monitoring"""
        if not svm_ptr:
            return
            
        start_time = time.time()
        
        try:
            ctx_ptr = c_void_p(int(self.context.int_ptr))
            self._lib.clSVMFree(ctx_ptr, c_void_p(svm_ptr))
            
            deallocation_time = time.time() - start_time
            
            # Remove from record and update statistics
            buffer_info = None
            if name and name in self.svm_buffers:
                buffer_info = self.svm_buffers[name]
                del self.svm_buffers[name]
            else:
                # Find by pointer and remove
                for buffer_name, info in list(self.svm_buffers.items()):
                    if info['ptr'] == svm_ptr:
                        buffer_info = info
                        del self.svm_buffers[buffer_name]
                        break
            
            if buffer_info:
                self.allocation_stats['current_allocated_bytes'] -= buffer_info['size']
                self.allocation_stats['total_deallocations'] += 1
                self.allocation_stats['deallocation_times'].append(deallocation_time * 1000)
                
                logger.debug(f"SVM free successful: {name or 'unnamed'} ({deallocation_time*1000:.2f}ms)")
            
        except Exception as e:
            logger.error(f"SVM free failed: {e}")
            raise
    
    def get_device_info(self) -> Dict[str, Any]:
        """Get device information - enhanced version"""
        info = {
            'device_name': self.device.name,
            'device_vendor': self.device.vendor,
            'opencl_version': self.device.opencl_c_version,
            'driver_version': getattr(self.device, 'driver_version', 'unknown'),
            'svm_capabilities': self.svm_capabilities,
            'max_memory_alloc': self.device.max_mem_alloc_size,
            'global_memory': self.device.global_mem_size,
            'allocation_stats': self.allocation_stats.copy(),
            'current_buffers': len(self.svm_buffers)
        }
        
        # Add environment info
        if hasattr(self.lib_loader, 'env_info'):
            info['environment_info'] = self.lib_loader.env_info
            
        # Calculate statistics summary
        if self.allocation_stats['allocation_times']:
            info['performance_summary'] = {
                'avg_allocation_time_ms': sum(self.allocation_stats['allocation_times']) / len(self.allocation_stats['allocation_times']),
                'max_allocation_time_ms': max(self.allocation_stats['allocation_times']),
                'min_allocation_time_ms': min(self.allocation_stats['allocation_times'])
            }
            
        if self.allocation_stats['deallocation_times']:
            info['performance_summary'].update({
                'avg_deallocation_time_ms': sum(self.allocation_stats['deallocation_times']) / len(self.allocation_stats['deallocation_times']),
                'max_deallocation_time_ms': max(self.allocation_stats['deallocation_times']),
                'min_deallocation_time_ms': min(self.allocation_stats['deallocation_times'])
            })
            
        return info
    
    def get_allocation_stats(self) -> Dict[str, Any]:
        """Get detailed allocation statistics"""
        stats = self.allocation_stats.copy()
        
        # Calculate success rate
        total_attempts = stats['total_allocations'] + stats['failed_allocations']
        if total_attempts > 0:
            stats['success_rate'] = stats['total_allocations'] / total_attempts
        else:
            stats['success_rate'] = 0.0
        
        # Memory utilization
        if stats['peak_allocated_bytes'] > 0:
            stats['current_utilization'] = stats['current_allocated_bytes'] / stats['peak_allocated_bytes']
        else:
            stats['current_utilization'] = 0.0
        
        # Average buffer size
        if self.svm_buffers:
            total_size = sum(buf['size'] for buf in self.svm_buffers.values())
            stats['avg_buffer_size'] = total_size / len(self.svm_buffers)
        else:
            stats['avg_buffer_size'] = 0
        
        return stats
    
    def cleanup(self):
        """Cleanup all SVM resources - enhanced statistics"""
        logger.info("Cleaning up SVM resources...")
        
        cleanup_start = time.time()
        
        # Free all registered buffers
        for name, info in list(self.svm_buffers.items()):
            try:
                self.free(info['ptr'], name)
                logger.debug(f"Released SVM buffer: {name}")
            except Exception as e:
                logger.error(f"Failed to release buffer {name}: {e}")
        
        cleanup_time = time.time() - cleanup_start
        
        # Final statistics report
        stats = self.get_allocation_stats()
        logger.info(f"SVM usage statistics summary:")
        logger.info(f"   Total allocation count: {stats['total_allocations']}")
        logger.info(f"   Total deallocation count: {stats['total_deallocations']}")
        logger.info(f"   Success rate: {stats['success_rate']:.1%}")
        logger.info(f"   Peak memory: {stats['peak_allocated_bytes'] / 1024 / 1024:.1f} MB")
        logger.info(f"   Cleanup time: {cleanup_time*1000:.1f} ms")
        
        if 'performance_summary' in self.get_device_info():
            perf = self.get_device_info()['performance_summary']
            logger.info(f"   Average allocation time: {perf['avg_allocation_time_ms']:.2f} ms")
        
        self.svm_buffers.clear()
        logger.info("SVM resources cleanup completed")

def detect_usable_svm_devices(device_type: str = 'gpu', 
                            do_reality_check: bool = True) -> List[Dict[str, Any]]:
    """Detect all actually usable SVM devices (using improved library loading)"""
    usable_devices = []
    
    try:
        platforms = cl.get_platforms()
        
        for platform in platforms:
            logger.info(f"\nChecking platform: {platform.name}")
            
            try:
                if device_type.lower() == 'gpu':
                    devices = platform.get_devices(device_type=cl.device_type.GPU)
                elif device_type.lower() == 'cpu':
                    devices = platform.get_devices(device_type=cl.device_type.CPU)
                else:
                    devices = platform.get_devices()  # All devices
            except:
                continue
            
            for device in devices:
                logger.info(f"   Checking device: {device.name}")
                
                try:
                    # Use improved SVM checker
                    svm_caps = EnhancedSVMCapabilityChecker.check_svm_support(
                        device, do_reality_check=do_reality_check
                    )
                    
                    device_info = {
                        'device': device,
                        'platform': platform,
                        'name': device.name,
                        'vendor': device.vendor,
                        'capabilities': svm_caps
                    }
                    
                    if svm_caps['has_svm']:
                        if do_reality_check:
                            if svm_caps['actually_usable']:
                                logger.info(f"     SVM tested usable")
                                
                                # Show performance info
                                if 'performance_summary' in svm_caps:
                                    perf = svm_caps['performance_summary']
                                    if perf:
                                        largest_size = max(perf.keys())
                                        largest_perf = perf[largest_size]
                                        logger.info(f"       Performance: {largest_perf['write_bandwidth']:.1f} MB/s")
                                
                                usable_devices.append(device_info)
                            else:
                                logger.warning(f"     SVM claims support but reality test failed")
                                warnings = svm_caps.get('warnings', [])
                                for warning in warnings[:2]:  # Show only first 2 warnings
                                    logger.warning(f"       {warning}")
                        else:
                            logger.info(f"     SVM marked as supported (not reality tested)")
                            usable_devices.append(device_info)
                    else:
                        logger.info(f"     Does not support SVM")
                
                except Exception as e:
                    logger.error(f"     Check process exception: {e}")
    
    except Exception as e:
        logger.error(f"Platform scan exception: {e}")
    
    return usable_devices

def create_svm_manager(device_type: str = 'gpu', 
                     prefer_tested: bool = True) -> Optional[ImprovedSVMManager]:
    """Factory function for creating SVM manager (using improved library loading)"""
    try:
        # Detect available devices
        usable_devices = detect_usable_svm_devices(device_type, do_reality_check=prefer_tested)
        
        if not usable_devices:
            logger.warning("No SVM supporting devices found")
            return None
        
        # Choose best device (can add more complex selection logic)
        best_device_info = usable_devices[0]
        
        # If multiple devices, choose the one with best performance
        if len(usable_devices) > 1:
            logger.info(f"Found {len(usable_devices)} available devices, selecting best device...")
            
            best_score = 0
            for device_info in usable_devices:
                score = 0
                caps = device_info['capabilities']
                
                # Calculate score based on various factors
                if caps.get('actually_usable', False):
                    score += 100
                if caps.get('fine_grain_buffer', False):
                    score += 50
                if caps.get('atomics', False):
                    score += 25
                
                # Performance bonus
                if 'performance_summary' in caps and caps['performance_summary']:
                    perf = caps['performance_summary']
                    largest_size = max(perf.keys())
                    bandwidth = perf[largest_size]['write_bandwidth']
                    score += min(bandwidth / 10, 50)  # Max 50 points
                
                if score > best_score:
                    best_score = score
                    best_device_info = device_info
                    
            logger.info(f"Selected device: {best_device_info['name']} (score: {best_score})")
        
        device = best_device_info['device']
        context = cl.Context([device])
        queue = cl.CommandQueue(context)
        
        return ImprovedSVMManager(context, queue, skip_reality_check=not prefer_tested)
        
    except Exception as e:
        logger.error(f"SVM manager creation failed: {e}")
        return None

def comprehensive_svm_test():
    """Comprehensive SVM functionality test (using improved library loading mechanism)"""
    logger.info("Starting comprehensive SVM functionality test (with improved library loading)...")
    
    # Setup debug mode
    os.environ['OPENCL_DEBUG'] = '1'
    
    # First detect all available devices
    logger.info("\nStage 1: Device detection")
    usable_devices = detect_usable_svm_devices('gpu', do_reality_check=True)
    
    if not usable_devices:
        logger.error("No available SVM devices found")
        return False
    
    logger.info(f"\nFound {len(usable_devices)} available SVM devices")
    
    # Show environment info
    if usable_devices and 'capabilities' in usable_devices[0]:
        caps = usable_devices[0]['capabilities']
        if 'environment_info' in caps:
            env_info = caps['environment_info']
            logger.info(f"\nEnvironment information:")
            logger.info(f"   ICD available: {env_info.get('icd_available', 'unknown')}")
            vendors = env_info.get('vendors_found', [])
            if vendors:
                logger.info(f"   Vendors detected: {[v['name'] for v in vendors]}")
                
            if 'system_resources' in env_info:
                res = env_info['system_resources']
                logger.info(f"   System resources: {res['total_memory_gb']:.1f}GB Memory, {res['cpu_count']} CPU cores")
    
    # Create manager for detailed testing
    logger.info("\nStage 2: Functionality test")
    manager = create_svm_manager('gpu', prefer_tested=True)
    if not manager:
        logger.error("Unable to create SVM manager")
        return False
    
    try:
        # Simple test
        logger.info(f"\nBasic allocation test...")
        
        test_sizes = [1024, 4096, 16384, 65536]  # Different size tests
        
        for size in test_sizes:
            data = np.random.rand(size // 4).astype(np.float32)  # 4 bytes per float32
            
            # Allocate SVM memory
            start_time = time.time()
            ptr = manager.allocate(data.nbytes, name=f"test_buffer_{size}")
            alloc_time = (time.time() - start_time) * 1000
            
            logger.info(f"Successfully allocated {size} bytes SVM memory ({alloc_time:.2f}ms)")
            
            # Free memory
            start_time = time.time()
            manager.free(ptr, f"test_buffer_{size}")
            free_time = (time.time() - start_time) * 1000
            
            logger.info(f"Successfully deallocated SVM memory ({free_time:.2f}ms)")
        
        # Stress test
        logger.info(f"\nStress allocation test...")
        allocated_ptrs = []
        
        try:
            for i in range(20):  # Try allocating 20 buffers
                ptr = manager.allocate(1024*1024, name=f"stress_buffer_{i}")  # 1MB each
                allocated_ptrs.append((ptr, f"stress_buffer_{i}"))
                
            logger.info(f"Stress test: Successfully allocated {len(allocated_ptrs)} buffers of 1MB")
            
        finally:
            # Clean up all stress test buffers
            for ptr, name in allocated_ptrs:
                manager.free(ptr, name)
        
        # Show device info and statistics
        device_info = manager.get_device_info()
        logger.info(f"\nDevice information:")
        logger.info(f"   Device: {device_info['device_name']}")
        logger.info(f"   Vendor: {device_info['device_vendor']}")
        logger.info(f"   Driver version: {device_info['driver_version']}")
        
        if 'environment_info' in device_info:
            env_info = device_info['environment_info']
            logger.info(f"   Library load mode: {'ICD' if env_info.get('icd_available') else 'Direct loading'}")
        
        # Show performance statistics
        if 'performance_summary' in device_info:
            perf = device_info['performance_summary']
            logger.info(f"   Average allocation time: {perf['avg_allocation_time_ms']:.2f} ms")
            logger.info(f"   Max allocation time: {perf['max_allocation_time_ms']:.2f} ms")
            
        # Show allocation statistics
        alloc_stats = manager.get_allocation_stats()
        logger.info(f"   Allocation success rate: {alloc_stats['success_rate']:.1%}")
        logger.info(f"   Peak memory: {alloc_stats['peak_allocated_bytes'] / 1024 / 1024:.1f} MB")
        
        return True
        
    except Exception as e:
        logger.error(f"Test process exception: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        manager.cleanup()

if __name__ == "__main__":
    # Support command line parameters
    import sys
    
    if "--debug" in sys.argv:
        logging.getLogger().setLevel(logging.DEBUG)
        os.environ['OPENCL_DEBUG'] = '1'
    
    success = comprehensive_svm_test()
    if success:
        logger.info("\nAll SVM tests passed (with improved library loading)!")
    else:
        logger.error("\nSome SVM tests failed!")
        sys.exit(1)